package com.sofiya.mealplanner.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
public class MealPlanEntry {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDate date;
    private Long recipeId;
    private Double servingsOverride; // optional, if different from recipe.servingsDefault

    public MealPlanEntry() {}

    public MealPlanEntry(LocalDate date, Long recipeId, Double servingsOverride) {
        this.date = date;
        this.recipeId = recipeId;
        this.servingsOverride = servingsOverride;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public LocalDate getDate() { return date; }
    public void setDate(LocalDate date) { this.date = date; }
    public Long getRecipeId() { return recipeId; }
    public void setRecipeId(Long recipeId) { this.recipeId = recipeId; }
    public Double getServingsOverride() { return servingsOverride; }
    public void setServingsOverride(Double servingsOverride) { this.servingsOverride = servingsOverride; }
}
