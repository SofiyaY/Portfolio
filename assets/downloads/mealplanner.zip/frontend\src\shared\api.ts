import axios from 'axios'

const client = axios.create({ baseURL: 'http://localhost:8080/api', timeout: 3000 })

// Types
export interface IngredientRow {
  name: string
  quantity: number
  unit: string
  notes?: string
}

export interface Recipe {
  id?: number
  title: string
  servingsDefault: number
  instructions: string
  ingredients: IngredientRow[]
  imageUrl?: string
}

export interface MealPlanEntry {
  id?: number
  date: string // YYYY-MM-DD
  recipeId: number
  servingsOverride?: number
}

export interface PantryItem {
  id?: number
  name: string
  quantity: number
  unit: string
}

export interface GroceryItem {
  name: string
  quantityNeeded: number
  unit: string
}

// Sample recipes for initial data
const SAMPLE_RECIPES: Recipe[] = [
  {
    id: 1,
    title: 'Spaghetti Bolognese',
    servingsDefault: 4,
    instructions: '1. Brown the meat\n2. Add tomato sauce\n3. Simmer 20 min\n4. Cook pasta\n5. Serve',
    imageUrl: 'https://images.unsplash.com/photo-1598866594230-a7c12756260f?w=800&h=600&fit=crop',
    ingredients: [
      { name: 'Spaghetti', quantity: 400, unit: 'g', notes: '' },
      { name: 'Ground beef', quantity: 500, unit: 'g', notes: '' },
      { name: 'Tomato sauce', quantity: 400, unit: 'ml', notes: '' },
      { name: 'Onion', quantity: 1, unit: 'stk', notes: 'diced' },
      { name: 'Garlic', quantity: 2, unit: 'cloves', notes: '' },
    ]
  },
  {
    id: 2,
    title: 'Chicken Stir Fry',
    servingsDefault: 2,
    instructions: '1. Slice chicken\n2. Stir fry veggies\n3. Add soy sauce\n4. Serve with rice',
    imageUrl: 'https://images.unsplash.com/photo-1603133872878-684f208fb84b?w=800&h=600&fit=crop',
    ingredients: [
      { name: 'Chicken breast', quantity: 300, unit: 'g', notes: '' },
      { name: 'Bell pepper', quantity: 2, unit: 'stk', notes: '' },
      { name: 'Broccoli', quantity: 200, unit: 'g', notes: '' },
      { name: 'Soy sauce', quantity: 3, unit: 'tbsp', notes: '' },
      { name: 'Rice', quantity: 200, unit: 'g', notes: '' },
    ]
  },
  {
    id: 3,
    title: 'Vegetable Soup',
    servingsDefault: 6,
    instructions: '1. Chop veggies\n2. Sauté in pot\n3. Add broth\n4. Simmer 30 min',
    imageUrl: 'https://images.unsplash.com/photo-1547592166-23ac45744acd?w=800&h=600&fit=crop',
    ingredients: [
      { name: 'Carrots', quantity: 3, unit: 'stk', notes: '' },
      { name: 'Celery', quantity: 3, unit: 'stalks', notes: '' },
      { name: 'Potatoes', quantity: 4, unit: 'stk', notes: '' },
      { name: 'Vegetable broth', quantity: 1, unit: 'L', notes: '' },
      { name: 'Onion', quantity: 1, unit: 'stk', notes: '' },
    ]
  },
  {
    id: 4,
    title: 'Tacos',
    servingsDefault: 4,
    instructions: '1. Cook meat with spices\n2. Warm tortillas\n3. Prepare toppings\n4. Assemble',
    imageUrl: 'https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=800&h=600&fit=crop',
    ingredients: [
      { name: 'Ground beef', quantity: 400, unit: 'g', notes: '' },
      { name: 'Taco shells', quantity: 8, unit: 'stk', notes: '' },
      { name: 'Lettuce', quantity: 100, unit: 'g', notes: 'shredded' },
      { name: 'Tomato', quantity: 2, unit: 'stk', notes: 'diced' },
      { name: 'Cheese', quantity: 100, unit: 'g', notes: 'shredded' },
      { name: 'Sour cream', quantity: 100, unit: 'ml', notes: '' },
    ]
  },
  {
    id: 5,
    title: 'Pancakes',
    servingsDefault: 2,
    instructions: '1. Mix dry ingredients\n2. Add wet ingredients\n3. Cook on griddle\n4. Serve with syrup',
    imageUrl: 'https://images.unsplash.com/photo-1567620905732-2d1ec7ab7445?w=800&h=600&fit=crop',
    ingredients: [
      { name: 'Flour', quantity: 200, unit: 'g', notes: '' },
      { name: 'Milk', quantity: 300, unit: 'ml', notes: '' },
      { name: 'Eggs', quantity: 2, unit: 'stk', notes: '' },
      { name: 'Butter', quantity: 30, unit: 'g', notes: 'melted' },
      { name: 'Maple syrup', quantity: 50, unit: 'ml', notes: '' },
    ]
  },
  {
    id: 6,
    title: 'Caesar Salad',
    servingsDefault: 2,
    instructions: '1. Chop romaine\n2. Make dressing\n3. Add croutons and parmesan\n4. Toss',
    imageUrl: 'https://images.unsplash.com/photo-1546793665-c74683f339c1?w=800&h=600&fit=crop',
    ingredients: [
      { name: 'Romaine lettuce', quantity: 1, unit: 'head', notes: '' },
      { name: 'Parmesan', quantity: 50, unit: 'g', notes: 'shaved' },
      { name: 'Croutons', quantity: 100, unit: 'g', notes: '' },
      { name: 'Caesar dressing', quantity: 100, unit: 'ml', notes: '' },
    ]
  },
  {
    id: 7,
    title: 'Lasagna',
    servingsDefault: 6,
    instructions: '1. Make meat sauce\n2. Layer with pasta sheets and bechamel\n3. Top with cheese\n4. Bake 45 min at 180°C',
    imageUrl: 'https://images.unsplash.com/photo-1574894709920-11b28e7367e3?w=800&h=600&fit=crop',
    ingredients: [
      { name: 'Lasagna sheets', quantity: 250, unit: 'g', notes: '' },
      { name: 'Ground beef', quantity: 500, unit: 'g', notes: '' },
      { name: 'Tomato sauce', quantity: 500, unit: 'ml', notes: '' },
      { name: 'Mozzarella', quantity: 200, unit: 'g', notes: 'shredded' },
      { name: 'Bechamel sauce', quantity: 400, unit: 'ml', notes: '' },
      { name: 'Parmesan', quantity: 50, unit: 'g', notes: 'grated' },
    ]
  },
  {
    id: 8,
    title: 'Salmon Salad Bowl',
    servingsDefault: 2,
    instructions: '1. Grill salmon fillet\n2. Boil eggs\n3. Chop vegetables\n4. Arrange in bowl with lettuce\n5. Top with salmon and dressing',
    imageUrl: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&h=600&fit=crop',
    ingredients: [
      { name: 'Salmon fillet', quantity: 300, unit: 'g', notes: '' },
      { name: 'Eggs', quantity: 2, unit: 'stk', notes: 'boiled' },
      { name: 'Lettuce', quantity: 100, unit: 'g', notes: '' },
      { name: 'Corn', quantity: 100, unit: 'g', notes: '' },
      { name: 'Cherry tomatoes', quantity: 100, unit: 'g', notes: '' },
      { name: 'Cucumber', quantity: 1, unit: 'stk', notes: 'sliced' },
      { name: 'Red cabbage', quantity: 50, unit: 'g', notes: 'shredded' },
      { name: 'Olive oil', quantity: 2, unit: 'tbsp', notes: 'for dressing' },
    ]
  },
  {
    id: 9,
    title: 'Chicken Curry',
    servingsDefault: 4,
    instructions: '1. Fry onion and garlic\n2. Add chicken pieces\n3. Add curry paste and coconut milk\n4. Simmer 25 min\n5. Serve with rice',
    imageUrl: 'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=800&h=600&fit=crop',
    ingredients: [
      { name: 'Chicken thighs', quantity: 600, unit: 'g', notes: 'boneless' },
      { name: 'Coconut milk', quantity: 400, unit: 'ml', notes: '' },
      { name: 'Curry paste', quantity: 3, unit: 'tbsp', notes: '' },
      { name: 'Onion', quantity: 1, unit: 'stk', notes: '' },
      { name: 'Rice', quantity: 300, unit: 'g', notes: '' },
    ]
  },
  {
    id: 10,
    title: 'Margherita Pizza',
    servingsDefault: 2,
    instructions: '1. Roll out dough\n2. Spread tomato sauce\n3. Add mozzarella and basil\n4. Bake 10-12 min at 250°C',
    imageUrl: 'https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=800&h=600&fit=crop',
    ingredients: [
      { name: 'Pizza dough', quantity: 400, unit: 'g', notes: '' },
      { name: 'Tomato sauce', quantity: 150, unit: 'ml', notes: '' },
      { name: 'Fresh mozzarella', quantity: 200, unit: 'g', notes: '' },
      { name: 'Fresh basil', quantity: 10, unit: 'leaves', notes: '' },
      { name: 'Olive oil', quantity: 1, unit: 'tbsp', notes: '' },
    ]
  },
  {
    id: 11,
    title: 'Beef Burger',
    servingsDefault: 4,
    instructions: '1. Form patties\n2. Grill 4 min each side\n3. Toast buns\n4. Assemble with toppings',
    imageUrl: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=800&h=600&fit=crop',
    ingredients: [
      { name: 'Ground beef', quantity: 500, unit: 'g', notes: '' },
      { name: 'Burger buns', quantity: 4, unit: 'stk', notes: '' },
      { name: 'Cheddar cheese', quantity: 4, unit: 'slices', notes: '' },
      { name: 'Lettuce', quantity: 4, unit: 'leaves', notes: '' },
      { name: 'Tomato', quantity: 1, unit: 'stk', notes: 'sliced' },
      { name: 'Onion', quantity: 1, unit: 'stk', notes: 'sliced' },
    ]
  },
  {
    id: 12,
    title: 'Pad Thai',
    servingsDefault: 2,
    instructions: '1. Soak noodles\n2. Stir fry shrimp and tofu\n3. Add noodles and sauce\n4. Top with peanuts and lime',
    imageUrl: 'https://images.unsplash.com/photo-1559314809-0d155014e29e?w=800&h=600&fit=crop',
    ingredients: [
      { name: 'Rice noodles', quantity: 200, unit: 'g', notes: '' },
      { name: 'Shrimp', quantity: 200, unit: 'g', notes: '' },
      { name: 'Tofu', quantity: 150, unit: 'g', notes: '' },
      { name: 'Eggs', quantity: 2, unit: 'stk', notes: '' },
      { name: 'Bean sprouts', quantity: 100, unit: 'g', notes: '' },
      { name: 'Peanuts', quantity: 50, unit: 'g', notes: 'crushed' },
    ]
  },
]

// Helper to get Monday of current week
function getMonday(date: Date): Date {
  const d = new Date(date)
  const day = d.getDay()
  const diff = d.getDate() - day + (day === 0 ? -6 : 1)
  d.setDate(diff)
  return d
}

function fmt(d: Date): string {
  return d.toISOString().slice(0, 10)
}

// Initial meal plan for current week
function getInitialMealPlan(): MealPlanEntry[] {
  const monday = getMonday(new Date())
  return [
    { id: 1, date: fmt(monday), recipeId: 5 },
    { id: 2, date: fmt(new Date(monday.getTime() + 86400000)), recipeId: 2 },
    { id: 3, date: fmt(new Date(monday.getTime() + 2 * 86400000)), recipeId: 1 },
    { id: 4, date: fmt(new Date(monday.getTime() + 3 * 86400000)), recipeId: 3 },
    { id: 5, date: fmt(new Date(monday.getTime() + 4 * 86400000)), recipeId: 4 },
    { id: 6, date: fmt(new Date(monday.getTime() + 5 * 86400000)), recipeId: 6 },
    { id: 7, date: fmt(new Date(monday.getTime() + 6 * 86400000)), recipeId: 1 },
  ]
}

// Sample pantry items
const SAMPLE_PANTRY: PantryItem[] = [
  { id: 1, name: 'Olive oil', quantity: 500, unit: 'ml' },
  { id: 2, name: 'Salt', quantity: 200, unit: 'g' },
  { id: 3, name: 'Pepper', quantity: 50, unit: 'g' },
  { id: 4, name: 'Rice', quantity: 1000, unit: 'g' },
  { id: 5, name: 'Spaghetti', quantity: 500, unit: 'g' },
  { id: 6, name: 'Flour', quantity: 500, unit: 'g' },
]

// Compute grocery list from meal plan
function computeGroceryList(): GroceryItem[] {
  const mealPlan = getInitialMealPlan()
  const needs = new Map<string, GroceryItem>()

  for (const entry of mealPlan) {
    const recipe = SAMPLE_RECIPES.find(r => r.id === entry.recipeId)
    if (!recipe) continue
    for (const ing of recipe.ingredients) {
      const key = `${ing.name.toLowerCase()}|${ing.unit.toLowerCase()}`
      const existing = needs.get(key)
      if (existing) {
        existing.quantityNeeded += ing.quantity
      } else {
        needs.set(key, { name: ing.name, quantityNeeded: ing.quantity, unit: ing.unit })
      }
    }
  }

  // Subtract pantry
  for (const p of SAMPLE_PANTRY) {
    const key = `${p.name.toLowerCase()}|${p.unit.toLowerCase()}`
    const item = needs.get(key)
    if (item) {
      item.quantityNeeded = Math.max(0, item.quantityNeeded - p.quantity)
    }
  }

  return Array.from(needs.values()).filter(g => g.quantityNeeded > 0)
}

// Local storage keys
const STORAGE_KEYS = {
  recipes: 'mealplanner_recipes',
  mealplan: 'mealplanner_mealplan',
  pantry: 'mealplanner_pantry',
}

function loadLocal<T>(key: string, fallback: T): T {
  try {
    const data = localStorage.getItem(key)
    return data ? JSON.parse(data) : fallback
  } catch {
    return fallback
  }
}

function saveLocal<T>(key: string, data: T): void {
  localStorage.setItem(key, JSON.stringify(data))
}

// Data version for cache invalidation
const DATA_VERSION = 10

// Initialize local storage with sample data
function initData() {
  const storedVersion = localStorage.getItem('mealplanner_version')
  if (storedVersion !== String(DATA_VERSION)) {
    localStorage.setItem('mealplanner_version', String(DATA_VERSION))
    saveLocal(STORAGE_KEYS.recipes, SAMPLE_RECIPES)
    saveLocal(STORAGE_KEYS.mealplan, getInitialMealPlan())
    saveLocal(STORAGE_KEYS.pantry, SAMPLE_PANTRY)
  }
}

initData()

// API with local storage fallback

let nextRecipeId = 100
let nextMealPlanId = 100
let nextPantryId = 100

export const api = {
  recipes: {
    list: async (): Promise<Recipe[]> => {
      try {
        return (await client.get('/recipes')).data
      } catch {
        return loadLocal<Recipe[]>(STORAGE_KEYS.recipes, SAMPLE_RECIPES)
      }
    },
    get: async (id: number): Promise<Recipe> => {
      try {
        return (await client.get(`/recipes/${id}`)).data
      } catch {
        const recipes = loadLocal<Recipe[]>(STORAGE_KEYS.recipes, SAMPLE_RECIPES)
        const recipe = recipes.find(r => r.id === id)
        if (!recipe) throw new Error('Recipe not found')
        return recipe
      }
    },
    create: async (r: Omit<Recipe, 'id'>): Promise<Recipe> => {
      try {
        return (await client.post('/recipes', r)).data
      } catch {
        const recipes = loadLocal<Recipe[]>(STORAGE_KEYS.recipes, SAMPLE_RECIPES)
        const newRecipe = { ...r, id: nextRecipeId++ }
        recipes.push(newRecipe)
        saveLocal(STORAGE_KEYS.recipes, recipes)
        return newRecipe
      }
    },
    update: async (id: number, r: Omit<Recipe, 'id'>): Promise<Recipe> => {
      try {
        return (await client.put(`/recipes/${id}`, r)).data
      } catch {
        const recipes = loadLocal<Recipe[]>(STORAGE_KEYS.recipes, SAMPLE_RECIPES)
        const index = recipes.findIndex(rec => rec.id === id)
        if (index === -1) throw new Error('Recipe not found')
        recipes[index] = { ...r, id }
        saveLocal(STORAGE_KEYS.recipes, recipes)
        return recipes[index]
      }
    },
    delete: async (id: number): Promise<void> => {
      try {
        await client.delete(`/recipes/${id}`)
      } catch {
        const recipes = loadLocal<Recipe[]>(STORAGE_KEYS.recipes, SAMPLE_RECIPES)
        const filtered = recipes.filter(r => r.id !== id)
        saveLocal(STORAGE_KEYS.recipes, filtered)
      }
    },
  },
  mealplan: {
    list: async (from: string, to: string): Promise<MealPlanEntry[]> => {
      try {
        return (await client.get('/mealplan', { params: { from, to } })).data
      } catch {
        const entries = loadLocal<MealPlanEntry[]>(STORAGE_KEYS.mealplan, getInitialMealPlan())
        return entries.filter(e => e.date >= from && e.date <= to)
      }
    },
    create: async (e: Omit<MealPlanEntry, 'id'>): Promise<MealPlanEntry> => {
      try {
        return (await client.post('/mealplan', e)).data
      } catch {
        const entries = loadLocal<MealPlanEntry[]>(STORAGE_KEYS.mealplan, getInitialMealPlan())
        const newEntry = { ...e, id: nextMealPlanId++ }
        entries.push(newEntry)
        saveLocal(STORAGE_KEYS.mealplan, entries)
        return newEntry
      }
    },
    delete: async (id: number): Promise<void> => {
      try {
        await client.delete(`/mealplan/${id}`)
      } catch {
        const entries = loadLocal<MealPlanEntry[]>(STORAGE_KEYS.mealplan, getInitialMealPlan())
        const filtered = entries.filter(e => e.id !== id)
        saveLocal(STORAGE_KEYS.mealplan, filtered)
      }
    },
  },
  pantry: {
    list: async (): Promise<PantryItem[]> => {
      try {
        return (await client.get('/pantry')).data
      } catch {
        return loadLocal<PantryItem[]>(STORAGE_KEYS.pantry, SAMPLE_PANTRY)
      }
    },
    create: async (p: Omit<PantryItem, 'id'>): Promise<PantryItem> => {
      try {
        return (await client.post('/pantry', p)).data
      } catch {
        const items = loadLocal<PantryItem[]>(STORAGE_KEYS.pantry, SAMPLE_PANTRY)
        const newItem = { ...p, id: nextPantryId++ }
        items.push(newItem)
        saveLocal(STORAGE_KEYS.pantry, items)
        return newItem
      }
    },
    update: async (id: number, p: Omit<PantryItem, 'id'>): Promise<PantryItem> => {
      try {
        return (await client.put(`/pantry/${id}`, p)).data
      } catch {
        const items = loadLocal<PantryItem[]>(STORAGE_KEYS.pantry, SAMPLE_PANTRY)
        const index = items.findIndex(item => item.id === id)
        if (index === -1) throw new Error('Item not found')
        items[index] = { ...p, id }
        saveLocal(STORAGE_KEYS.pantry, items)
        return items[index]
      }
    },
    delete: async (id: number): Promise<void> => {
      try {
        await client.delete(`/pantry/${id}`)
      } catch {
        const items = loadLocal<PantryItem[]>(STORAGE_KEYS.pantry, SAMPLE_PANTRY)
        const filtered = items.filter(item => item.id !== id)
        saveLocal(STORAGE_KEYS.pantry, filtered)
      }
    },
  },
  grocery: {
    list: async (from: string, to: string): Promise<GroceryItem[]> => {
      try {
        return (await client.get('/grocery-list', { params: { from, to } })).data
      } catch {
        // Compute from local data
        const recipes = loadLocal<Recipe[]>(STORAGE_KEYS.recipes, SAMPLE_RECIPES)
        const mealplan = loadLocal<MealPlanEntry[]>(STORAGE_KEYS.mealplan, getInitialMealPlan())
        const pantry = loadLocal<PantryItem[]>(STORAGE_KEYS.pantry, SAMPLE_PANTRY)

        const relevantEntries = mealplan.filter(e => e.date >= from && e.date <= to)
        const needs = new Map<string, GroceryItem>()

        for (const entry of relevantEntries) {
          const recipe = recipes.find(r => r.id === entry.recipeId)
          if (!recipe) continue
          for (const ing of recipe.ingredients) {
            const key = `${ing.name.toLowerCase()}|${ing.unit.toLowerCase()}`
            const existing = needs.get(key)
            if (existing) {
              existing.quantityNeeded += ing.quantity
            } else {
              needs.set(key, { name: ing.name, quantityNeeded: ing.quantity, unit: ing.unit })
            }
          }
        }

        // Subtract pantry - match by name only (case insensitive), convert units if same type
        for (const p of pantry) {
          const pantryNameLower = p.name.toLowerCase()
          // Find all matching items by name
          for (const [key, item] of needs.entries()) {
            if (key.startsWith(pantryNameLower + '|')) {
              // Same name - subtract quantity (assuming same unit type for simplicity)
              item.quantityNeeded = Math.max(0, item.quantityNeeded - p.quantity)
            }
          }
        }

        return Array.from(needs.values()).filter(g => g.quantityNeeded > 0)
      }
    },
  },
}
