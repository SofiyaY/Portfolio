package com.sofiya.mealplanner.repo;

import com.sofiya.mealplanner.model.MealPlanEntry;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface MealPlanRepository extends JpaRepository<MealPlanEntry, Long> {
    List<MealPlanEntry> findByDateBetween(LocalDate from, LocalDate to);
}
