import { Link, NavLink, Route, Routes } from 'react-router-dom'
import Recipes from './pages/Recipes'
import Plan from './pages/Plan'
import Grocery from './pages/Grocery'
import Pantry from './pages/Pantry'

export default function App() {
  return (
    <div className="min-h-screen bg-stone-100 text-slate-800">
      <header className="sticky top-0 z-10 bg-white/95 backdrop-blur shadow-sm">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <Link to="/" className="text-3xl text-brand-700" style={{ fontFamily: "'Great Vibes', cursive" }}>Meal Planner</Link>
          <nav className="flex gap-4">
            <NavLink to="/recipes" className={({isActive}) => isActive ? 'text-brand-700 font-medium' : 'text-slate-600 hover:text-brand-700'}>Recipes</NavLink>
            <NavLink to="/plan" className={({isActive}) => isActive ? 'text-brand-700 font-medium' : 'text-slate-600 hover:text-brand-700'}>Plan</NavLink>
            <NavLink to="/grocery" className={({isActive}) => isActive ? 'text-brand-700 font-medium' : 'text-slate-600 hover:text-brand-700'}>Grocery</NavLink>
            <NavLink to="/pantry" className={({isActive}) => isActive ? 'text-brand-700 font-medium' : 'text-slate-600 hover:text-brand-700'}>Pantry</NavLink>
          </nav>
        </div>
      </header>
      <main className="max-w-6xl mx-auto px-4 py-8">
        <Routes>
          <Route path="/" element={<Recipes />} />
          <Route path="/recipes" element={<Recipes />} />
          <Route path="/plan" element={<Plan />} />
          <Route path="/grocery" element={<Grocery />} />
          <Route path="/pantry" element={<Pantry />} />
        </Routes>
      </main>
    </div>
  )
}
