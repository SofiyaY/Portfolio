# MealPlanner (React + TypeScript + Tailwind + Spring Boot)

This workspace contains a modern frontend and a Java backend. Default profile uses H2 so you can run without MySQL immediately. When ready, switch to the `mysql` profile and configure your credentials.

## Structure
- `frontend/` – React + TypeScript + Tailwind (Vite)
- `backend/` – Spring Boot (Java 17), JPA, H2 (default) and optional MySQL

## Run (after installing tools)

Backend (Java 17):
- In VS Code, open a terminal in `backend/` and run `./gradlew bootRun` (PowerShell: `gradlew.bat bootRun`).
- Switch to MySQL later with `--spring.profiles.active=mysql` and update `application.yml` creds.

Frontend (Node 18+):
- In `frontend/`, run `npm install` once, then `npm run dev`.
- App will be at http://localhost:5173.

## API endpoints (MVP)
- `GET /api/recipes` – list
- `POST /api/recipes` – create
- `GET /api/mealplan?from=YYYY-MM-DD&to=YYYY-MM-DD` – list plan entries in range
- `POST /api/mealplan` – create entry
- `DELETE /api/mealplan/{id}` – delete entry
- `GET /api/grocery-list?from=YYYY-MM-DD&to=YYYY-MM-DD` – computed list (sum recipes in range minus pantry)
- `GET/POST/PUT/DELETE /api/pantry` – manage pantry

## Notes
- Beautiful UI: Tailwind + a small design system (buttons/inputs/cards) already wired up.
- No Git setup yet as requested; we can initialize after you approve.
- When you install MySQL, set username/password in `backend/src/main/resources/application.yml` under the `mysql` profile and run with `--spring.profiles.active=mysql`.
