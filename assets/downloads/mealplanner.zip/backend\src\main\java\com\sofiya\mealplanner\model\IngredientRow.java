package com.sofiya.mealplanner.model;

import jakarta.persistence.Embeddable;

@Embeddable
public class IngredientRow {
    private String name;
    private double quantity;
    private String unit; // e.g., g, ml, stk
    private String notes;

    public IngredientRow() {}

    public IngredientRow(String name, double quantity, String unit, String notes) {
        this.name = name;
        this.quantity = quantity;
        this.unit = unit;
        this.notes = notes;
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public double getQuantity() { return quantity; }
    public void setQuantity(double quantity) { this.quantity = quantity; }

    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
}
