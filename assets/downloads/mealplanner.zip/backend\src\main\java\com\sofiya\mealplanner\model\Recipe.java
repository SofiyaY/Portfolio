package com.sofiya.mealplanner.model;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
public class Recipe {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;
    private int servingsDefault = 2;

    @Column(length = 8000)
    private String instructions;

    @ElementCollection
    @CollectionTable(name = "recipe_ingredients", joinColumns = @JoinColumn(name = "recipe_id"))
    private List<IngredientRow> ingredients = new ArrayList<>();

    public Recipe() {}

    public Recipe(String title, int servingsDefault, String instructions) {
        this.title = title;
        this.servingsDefault = servingsDefault;
        this.instructions = instructions;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public int getServingsDefault() { return servingsDefault; }
    public void setServingsDefault(int servingsDefault) { this.servingsDefault = servingsDefault; }

    public String getInstructions() { return instructions; }
    public void setInstructions(String instructions) { this.instructions = instructions; }

    public List<IngredientRow> getIngredients() { return ingredients; }
    public void setIngredients(List<IngredientRow> ingredients) { this.ingredients = ingredients; }
}
