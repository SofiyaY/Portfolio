import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useState } from 'react'
import { api, Recipe, IngredientRow } from '../shared/api'

function getRecipeImage(recipe: Recipe): string | null {
  if (recipe.imageUrl && recipe.imageUrl.trim()) {
    return recipe.imageUrl
  }
  return null
}

const emptyIngredient = (): IngredientRow => ({ name: '', quantity: 0, unit: '', notes: '' })

export default function Recipes() {
  const qc = useQueryClient()
  const { data: recipes, isLoading, error } = useQuery({ queryKey: ['recipes'], queryFn: api.recipes.list })

  const createMutation = useMutation({
    mutationFn: api.recipes.create,
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['recipes'] }); resetForm() }
  })
  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: Omit<Recipe, 'id'> }) => api.recipes.update(id, data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['recipes'] }); resetForm() }
  })
  const deleteMutation = useMutation({
    mutationFn: api.recipes.delete,
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['recipes'] }); setViewingRecipe(null) }
  })

  // Form state
  const [showForm, setShowForm] = useState(false)
  const [editId, setEditId] = useState<number | null>(null)
  const [title, setTitle] = useState('')
  const [servings, setServings] = useState(2)
  const [instructions, setInstructions] = useState('')
  const [ingredients, setIngredients] = useState<IngredientRow[]>([emptyIngredient()])
  const [imageUrl, setImageUrl] = useState('')

  // Detail view state
  const [viewingRecipe, setViewingRecipe] = useState<Recipe | null>(null)

  const resetForm = () => {
    setShowForm(false)
    setEditId(null)
    setTitle('')
    setServings(2)
    setInstructions('')
    setIngredients([emptyIngredient()])
    setImageUrl('')
  }

  const openCreate = () => {
    resetForm()
    setViewingRecipe(null)
    setShowForm(true)
  }

  const openEdit = (r: Recipe) => {
    setViewingRecipe(null)
    setEditId(r.id!)
    setTitle(r.title)
    setServings(r.servingsDefault)
    setInstructions(r.instructions || '')
    setImageUrl(r.imageUrl || '')
    // Deep copy ingredients to avoid mutation issues
    const ingredientsCopy = r.ingredients && r.ingredients.length > 0 
      ? r.ingredients.map(ing => ({ ...ing }))
      : [emptyIngredient()]
    setIngredients(ingredientsCopy)
    setShowForm(true)
  }

  const handleSave = () => {
    const filteredIngredients = ingredients.filter(i => i.name.trim() !== '')
    const data: Omit<Recipe, 'id'> = {
      title: title.trim(),
      servingsDefault: servings,
      instructions,
      ingredients: filteredIngredients,
      imageUrl: imageUrl.trim() || undefined
    }
    if (!data.title) return alert('Title is required')
    if (editId) {
      updateMutation.mutate({ id: editId, data })
    } else {
      createMutation.mutate(data)
    }
  }

  const updateIngredient = (index: number, field: keyof IngredientRow, value: string | number) => {
    setIngredients(prev => {
      const copy = [...prev]
      copy[index] = { ...copy[index], [field]: value }
      return copy
    })
  }

  const addIngredientRow = () => setIngredients(prev => [...prev, emptyIngredient()])
  const removeIngredientRow = (index: number) => {
    if (ingredients.length === 1) {
      // Keep at least one row, just clear it
      setIngredients([emptyIngredient()])
    } else {
      setIngredients(prev => prev.filter((_, i) => i !== index))
    }
  }

  const openRecipeDetail = (r: Recipe) => {
    setShowForm(false)
    setViewingRecipe(r)
  }

  const closeDetail = () => {
    setViewingRecipe(null)
  }

  if (isLoading) return <p className="text-slate-500">Loading recipes...</p>
  if (error) return <p className="text-red-500">Error loading recipes</p>

  // Detail View
  if (viewingRecipe) {
    const instructionSteps = viewingRecipe.instructions
      ? viewingRecipe.instructions.split('\n').filter(s => s.trim())
      : []

    return (
      <div>
        <button 
          className="text-brand-600 hover:underline mb-4 flex items-center gap-1"
          onClick={closeDetail}
        >
          ← Back to recipes
        </button>
        
        <div className="card overflow-hidden">
          {/* Hero image or placeholder */}
          {getRecipeImage(viewingRecipe) ? (
            <img 
              src={getRecipeImage(viewingRecipe)!} 
              alt={viewingRecipe.title}
              className="w-full h-64 object-cover"
            />
          ) : (
            <div className="w-full h-64 bg-slate-200 flex items-center justify-center">
              <span className="text-slate-400 text-lg">No image</span>
            </div>
          )}
          
          <div className="p-6">
            <div className="flex justify-between items-start mb-4">
              <h1 className="text-2xl font-bold">{viewingRecipe.title}</h1>
              <span className="bg-brand-100 text-brand-700 px-3 py-1 rounded-full text-sm font-medium">
                {viewingRecipe.servingsDefault} servings
              </span>
            </div>

            {/* Ingredients */}
            <div className="mb-6">
              <h2 className="text-lg font-semibold mb-3">Ingredients</h2>
              {viewingRecipe.ingredients && viewingRecipe.ingredients.length > 0 ? (
                <ul className="grid sm:grid-cols-2 gap-2">
                  {viewingRecipe.ingredients.map((ing, i) => (
                    <li key={i} className="flex items-center gap-2 bg-slate-50 rounded-lg p-3">
                      <span className="w-2 h-2 bg-brand-500 rounded-full"></span>
                      <span className="font-medium">{ing.name}</span>
                      <span className="text-slate-500 ml-auto">
                        {ing.quantity > 0 && `${ing.quantity} ${ing.unit}`}
                      </span>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-slate-500 italic">No ingredients listed</p>
              )}
            </div>

            {/* Instructions */}
            <div className="mb-6">
              <h2 className="text-lg font-semibold mb-3">Instructions</h2>
              {instructionSteps.length > 0 ? (
                <ol className="space-y-3">
                  {instructionSteps.map((step, i) => (
                    <li key={i} className="flex gap-4 bg-slate-50 rounded-lg p-4">
                      <span className="flex-shrink-0 w-8 h-8 bg-brand-600 text-white rounded-full flex items-center justify-center font-bold text-sm">
                        {i + 1}
                      </span>
                      <p className="pt-1">{step.replace(/^\d+\.\s*/, '')}</p>
                    </li>
                  ))}
                </ol>
              ) : (
                <p className="text-slate-500 italic">No instructions provided</p>
              )}
            </div>

            {/* Actions */}
            <div className="flex gap-3 pt-4 border-t">
              <button className="btn" onClick={() => openEdit(viewingRecipe)}>
                Edit Recipe
              </button>
              <button 
                className="btn bg-red-500 hover:bg-red-600"
                onClick={() => {
                  if (confirm(`Delete "${viewingRecipe.title}"?`)) {
                    deleteMutation.mutate(viewingRecipe.id!)
                  }
                }}
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-semibold">Recipes</h1>
        {!showForm && (
          <button className="btn" onClick={openCreate}>+ Add Recipe</button>
        )}
      </div>

      {/* Form */}
      {showForm && (
        <div className="card p-6 mb-6">
          <h2 className="text-lg font-medium mb-4">{editId ? 'Edit Recipe' : 'New Recipe'}</h2>
          <div className="grid gap-4">
            {/* Title + Servings */}
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-600 mb-1">Title *</label>
                <input 
                  className="input" 
                  value={title} 
                  onChange={e => setTitle(e.target.value)} 
                  placeholder="e.g. Spaghetti Bolognese" 
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-600 mb-1">Servings</label>
                <input 
                  type="number" 
                  min={1} 
                  className="input" 
                  value={servings} 
                  onChange={e => setServings(+e.target.value || 1)} 
                />
              </div>
            </div>

            {/* Image URL */}
            <div>
              <label className="block text-sm font-medium text-slate-600 mb-1">Image URL (optional)</label>
              <input 
                className="input" 
                value={imageUrl} 
                onChange={e => setImageUrl(e.target.value)} 
                placeholder="https://example.com/image.jpg" 
              />
              <p className="text-xs text-slate-400 mt-1">Paste a URL to an image, or leave empty for "No image"</p>
            </div>

            {/* Ingredients */}
            <div>
              <label className="block text-sm font-medium text-slate-600 mb-2">
                Ingredients ({ingredients.filter(i => i.name.trim()).length} added)
              </label>
              <div className="space-y-2 bg-slate-50 p-4 rounded-lg">
                {/* Header row */}
                <div className="grid grid-cols-[1fr_80px_80px_32px] gap-2 text-xs text-slate-500 font-medium px-2">
                  <span>Name</span>
                  <span>Amount</span>
                  <span>Unit</span>
                  <span></span>
                </div>
                {ingredients.map((ing, i) => (
                  <div key={i} className="grid grid-cols-[1fr_80px_80px_32px] gap-2 items-center bg-white p-2 rounded border">
                    <input
                      className="input border-0 shadow-none min-w-0"
                      placeholder="e.g. Sugar"
                      value={ing.name}
                      onChange={e => updateIngredient(i, 'name', e.target.value)}
                    />
                    <input
                      type="number"
                      className="input border-0 shadow-none"
                      placeholder="300"
                      value={ing.quantity || ''}
                      onChange={e => updateIngredient(i, 'quantity', +e.target.value)}
                    />
                    <input
                      className="input border-0 shadow-none"
                      placeholder="ml"
                      value={ing.unit}
                      onChange={e => updateIngredient(i, 'unit', e.target.value)}
                    />
                    <button
                      type="button"
                      className="text-red-500 hover:text-red-700 hover:bg-red-50 rounded-full w-8 h-8 flex items-center justify-center text-lg"
                      onClick={() => removeIngredientRow(i)}
                      title="Remove ingredient"
                    >×</button>
                  </div>
                ))}
                <button 
                  type="button" 
                  className="w-full py-2 border-2 border-dashed border-slate-300 rounded-lg text-slate-500 hover:border-brand-400 hover:text-brand-600 transition-colors" 
                  onClick={addIngredientRow}
                >
                  + Add another ingredient
                </button>
              </div>
            </div>

            {/* Instructions */}
            <div>
              <label className="block text-sm font-medium text-slate-600 mb-1">
                Instructions (one step per line)
              </label>
              <textarea
                className="input min-h-[150px]"
                value={instructions}
                onChange={e => setInstructions(e.target.value)}
                placeholder="1. Preheat oven to 180°C&#10;2. Mix ingredients in a bowl&#10;3. Pour into baking dish&#10;4. Bake for 30 minutes"
              />
              <p className="text-xs text-slate-400 mt-1">Tip: Write each step on a new line for best display</p>
            </div>

            {/* Actions */}
            <div className="flex gap-3 pt-2">
              <button 
                className="btn" 
                onClick={handleSave} 
                disabled={createMutation.isPending || updateMutation.isPending}
              >
                {createMutation.isPending || updateMutation.isPending ? 'Saving...' : 'Save Recipe'}
              </button>
              <button 
                type="button" 
                className="btn bg-slate-200 text-slate-700 hover:bg-slate-300" 
                onClick={resetForm}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Recipe List */}
      {(!recipes || recipes.length === 0) && !showForm ? (
        <div className="card p-8 text-center">
          <p className="text-slate-500 mb-4">No recipes yet. Add your first recipe to get started!</p>
          <button className="btn" onClick={openCreate}>+ Add Recipe</button>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {(recipes ?? []).map((r) => (
            <div 
              key={r.id} 
              className="card overflow-hidden hover:shadow-lg transition-shadow cursor-pointer group"
              onClick={() => openRecipeDetail(r)}
            >
              {/* Image */}
              <div className="relative h-40 overflow-hidden">
                {getRecipeImage(r) ? (
                  <img 
                    src={getRecipeImage(r)!} 
                    alt={r.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                ) : (
                  <div className="w-full h-full bg-slate-200 flex items-center justify-center">
                    <span className="text-slate-400">No image</span>
                  </div>
                )}
                <div className="absolute top-2 right-2 bg-white/90 backdrop-blur px-2 py-1 rounded text-xs font-medium">
                  {r.servingsDefault} servings
                </div>
              </div>
              
              <div className="p-4">
                <h3 className="font-semibold text-lg mb-2 group-hover:text-brand-600 transition-colors">
                  {r.title}
                </h3>
                
                {/* Ingredients preview */}
                {r.ingredients && r.ingredients.length > 0 ? (
                  <p className="text-sm text-slate-500 mb-3">
                    {r.ingredients.slice(0, 3).map(i => i.name).join(', ')}
                    {r.ingredients.length > 3 && ` +${r.ingredients.length - 3} more`}
                  </p>
                ) : (
                  <p className="text-sm text-slate-400 italic mb-3">No ingredients listed</p>
                )}

                {/* Action buttons */}
                <div className="flex gap-2 pt-2 border-t">
                  <button 
                    className="text-sm text-brand-600 hover:underline"
                    onClick={(e) => { e.stopPropagation(); openEdit(r) }}
                  >
                    Edit
                  </button>
                  <button
                    className="text-sm text-red-500 hover:underline"
                    onClick={(e) => {
                      e.stopPropagation()
                      if (confirm(`Delete "${r.title}"?`)) deleteMutation.mutate(r.id!)
                    }}
                  >
                    Delete
                  </button>
                  <span className="text-sm text-slate-400 ml-auto">Click to view →</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
