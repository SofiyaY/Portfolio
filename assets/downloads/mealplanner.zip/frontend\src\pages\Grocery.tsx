import { useQuery } from '@tanstack/react-query'
import { useState, useMemo } from 'react'
import { api, GroceryItem } from '../shared/api'

// Helper: get Monday of the week containing `date`
function getMonday(date: Date): Date {
  const d = new Date(date)
  const day = d.getDay()
  const diff = d.getDate() - day + (day === 0 ? -6 : 1)
  d.setDate(diff)
  d.setHours(0, 0, 0, 0)
  return d
}

// Helper: format date as YYYY-MM-DD
function fmt(d: Date): string {
  return d.toISOString().slice(0, 10)
}

// Helper: add days to date
function addDays(d: Date, n: number): Date {
  const result = new Date(d)
  result.setDate(result.getDate() + n)
  return result
}

export default function Grocery() {
  const [weekStart, setWeekStart] = useState(() => getMonday(new Date()))
  const weekEnd = useMemo(() => addDays(weekStart, 6), [weekStart])

  const { data: items, isLoading, error } = useQuery({
    queryKey: ['grocery', fmt(weekStart), fmt(weekEnd)],
    queryFn: () => api.grocery.list(fmt(weekStart), fmt(weekEnd))
  })

  // Local state for checked items (not persisted to backend)
  const [checked, setChecked] = useState<Set<string>>(new Set())

  const toggleChecked = (key: string) => {
    const copy = new Set(checked)
    if (copy.has(key)) copy.delete(key)
    else copy.add(key)
    setChecked(copy)
  }

  // Navigate weeks
  const prevWeek = () => { setWeekStart(addDays(weekStart, -7)); setChecked(new Set()) }
  const nextWeek = () => { setWeekStart(addDays(weekStart, 7)); setChecked(new Set()) }
  const goToday = () => { setWeekStart(getMonday(new Date())); setChecked(new Set()) }

  // Filter items with quantity > 0
  const filteredItems = useMemo(() => (items ?? []).filter(g => g.quantityNeeded > 0), [items])

  if (isLoading) return <p className="text-slate-500">Loading grocery list...</p>
  if (error) return <p className="text-red-500">Error loading grocery list</p>

  return (
    <div>
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6 gap-4">
        <h1 className="text-2xl font-semibold">Grocery List</h1>
        <div className="flex items-center gap-2">
          <button className="btn bg-slate-200 text-slate-700 hover:bg-slate-300" onClick={prevWeek}>← Prev</button>
          <button className="btn bg-slate-200 text-slate-700 hover:bg-slate-300" onClick={goToday}>Today</button>
          <button className="btn bg-slate-200 text-slate-700 hover:bg-slate-300" onClick={nextWeek}>Next →</button>
        </div>
      </div>

      {/* Week range label */}
      <p className="text-slate-600 mb-4">
        Shopping list for{' '}
        {weekStart.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })} –{' '}
        {weekEnd.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}
      </p>

      {/* List */}
      {filteredItems.length === 0 ? (
        <div className="card p-8 text-center">
          <p className="text-slate-500">No items needed for this week.</p>
          <p className="text-slate-400 text-sm mt-2">
            Add recipes to your <a href="/plan" className="text-brand-600 underline">meal plan</a> to generate a shopping list.
          </p>
        </div>
      ) : (
        <ul className="card divide-y divide-slate-200">
          {filteredItems.map((g: GroceryItem) => {
            const key = `${g.name}|${g.unit}`
            const isChecked = checked.has(key)
            return (
              <li
                key={key}
                className={`p-4 flex items-center gap-3 cursor-pointer hover:bg-slate-50 transition-colors ${isChecked ? 'opacity-50' : ''}`}
                onClick={() => toggleChecked(key)}
              >
                <input
                  type="checkbox"
                  checked={isChecked}
                  onChange={() => {}}
                  className="h-5 w-5 text-brand-600 rounded border-slate-300"
                />
                <span className={`flex-1 font-medium ${isChecked ? 'line-through text-slate-400' : ''}`}>{g.name}</span>
                <span className={`text-slate-600 ${isChecked ? 'line-through' : ''}`}>
                  {g.quantityNeeded % 1 === 0 ? g.quantityNeeded : g.quantityNeeded.toFixed(1)} {g.unit}
                </span>
              </li>
            )
          })}
        </ul>
      )}

      {/* Summary */}
      {filteredItems.length > 0 && (
        <p className="text-sm text-slate-500 mt-4">
          {checked.size} of {filteredItems.length} items checked off
        </p>
      )}
    </div>
  )
}
