package com.sofiya.mealplanner.web;

import com.sofiya.mealplanner.service.GroceryService;
import com.sofiya.mealplanner.service.GroceryService.GroceryItem;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/grocery-list")
public class GroceryController {
    private final GroceryService svc;
    public GroceryController(GroceryService svc) { this.svc = svc; }

    @GetMapping
    public List<GroceryItem> list(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to
    ) { return svc.compute(from, to); }
}
