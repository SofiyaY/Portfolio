package com.sofiya.mealplanner.repo;

import com.sofiya.mealplanner.model.PantryItem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PantryRepository extends JpaRepository<PantryItem, Long> {}
