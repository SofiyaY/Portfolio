package com.sofiya.mealplanner.web;

import com.sofiya.mealplanner.model.MealPlanEntry;
import com.sofiya.mealplanner.repo.MealPlanRepository;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/mealplan")
public class MealPlanController {
    private final MealPlanRepository repo;
    public MealPlanController(MealPlanRepository repo) { this.repo = repo; }

    @GetMapping
    public List<MealPlanEntry> byRange(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to
    ) {
      return repo.findByDateBetween(from, to);
    }

    @PostMapping
    public MealPlanEntry create(@Validated @RequestBody MealPlanEntry e) { return repo.save(e); }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        if (!repo.existsById(id)) return ResponseEntity.notFound().build();
        repo.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
