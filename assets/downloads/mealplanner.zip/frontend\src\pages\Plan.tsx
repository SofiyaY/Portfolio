import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useState, useMemo } from 'react'
import { api, MealPlanEntry, Recipe } from '../shared/api'

// Helper: get Monday of the week containing `date`
function getMonday(date: Date): Date {
  const d = new Date(date)
  const day = d.getDay()
  const diff = d.getDate() - day + (day === 0 ? -6 : 1)
  d.setDate(diff)
  d.setHours(0, 0, 0, 0)
  return d
}

// Helper: format date as YYYY-MM-DD
function fmt(d: Date): string {
  return d.toISOString().slice(0, 10)
}

// Helper: add days to date
function addDays(d: Date, n: number): Date {
  const result = new Date(d)
  result.setDate(result.getDate() + n)
  return result
}

const WEEKDAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']

export default function Plan() {
  const qc = useQueryClient()
  const [weekStart, setWeekStart] = useState(() => getMonday(new Date()))

  // Week date range
  const weekEnd = useMemo(() => addDays(weekStart, 6), [weekStart])

  // Fetch recipes and meal plan entries for the week
  const { data: recipes } = useQuery({ queryKey: ['recipes'], queryFn: api.recipes.list })
  const { data: entries, isLoading } = useQuery({
    queryKey: ['mealplan', fmt(weekStart), fmt(weekEnd)],
    queryFn: () => api.mealplan.list(fmt(weekStart), fmt(weekEnd))
  })

  const createMutation = useMutation({
    mutationFn: api.mealplan.create,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['mealplan'] })
  })
  const deleteMutation = useMutation({
    mutationFn: api.mealplan.delete,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['mealplan'] })
  })

  // Modal state for adding a meal
  const [addingDate, setAddingDate] = useState<string | null>(null)
  const [selectedRecipeId, setSelectedRecipeId] = useState<number | ''>('')

  const openAddModal = (date: string) => {
    setAddingDate(date)
    setSelectedRecipeId('')
  }

  const closeModal = () => {
    setAddingDate(null)
    setSelectedRecipeId('')
  }

  const handleAdd = () => {
    if (addingDate && selectedRecipeId) {
      createMutation.mutate({ date: addingDate, recipeId: selectedRecipeId as number })
      closeModal()
    }
  }

  // Navigate weeks
  const prevWeek = () => setWeekStart(addDays(weekStart, -7))
  const nextWeek = () => setWeekStart(addDays(weekStart, 7))
  const goToday = () => setWeekStart(getMonday(new Date()))

  // Get recipes by id
  const recipeMap = useMemo(() => {
    const map = new Map<number, Recipe>()
    ;(recipes ?? []).forEach(r => r.id && map.set(r.id, r))
    return map
  }, [recipes])

  // Group entries by date
  const entriesByDate = useMemo(() => {
    const map = new Map<string, MealPlanEntry[]>()
    ;(entries ?? []).forEach(e => {
      const list = map.get(e.date) ?? []
      list.push(e)
      map.set(e.date, list)
    })
    return map
  }, [entries])

  return (
    <div>
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6 gap-4">
        <h1 className="text-2xl font-semibold">Weekly Plan</h1>
        <div className="flex items-center gap-2">
          <button className="btn bg-slate-200 text-slate-700 hover:bg-slate-300" onClick={prevWeek}>← Prev</button>
          <button className="btn bg-slate-200 text-slate-700 hover:bg-slate-300" onClick={goToday}>Today</button>
          <button className="btn bg-slate-200 text-slate-700 hover:bg-slate-300" onClick={nextWeek}>Next →</button>
        </div>
      </div>

      {/* Week range label */}
      <p className="text-slate-600 mb-4">
        {weekStart.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })} –{' '}
        {weekEnd.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}
      </p>

      {/* Week grid */}
      {isLoading ? (
        <p className="text-slate-500">Loading plan...</p>
      ) : (
        <div className="grid grid-cols-7 gap-2">
          {WEEKDAYS.map((day, i) => {
            const date = fmt(addDays(weekStart, i))
            const dayEntries = entriesByDate.get(date) ?? []
            const isToday = date === fmt(new Date())

            return (
              <div key={date} className={`card p-3 min-h-[140px] flex flex-col ${isToday ? 'ring-2 ring-brand-500' : ''}`}>
                <div className="text-xs font-medium text-slate-500 mb-1">{day}</div>
                <div className="text-sm font-semibold mb-2">{addDays(weekStart, i).getDate()}</div>

                {/* Meals for this day */}
                <div className="flex-1 space-y-1">
                  {dayEntries.map(entry => {
                    const recipe = recipeMap.get(entry.recipeId)
                    return (
                      <div key={entry.id} className="bg-brand-50 rounded px-2 py-1 text-xs flex justify-between items-center group">
                        <span className="truncate">{recipe?.title ?? `Recipe #${entry.recipeId}`}</span>
                        <button
                          className="text-red-400 hover:text-red-600 opacity-0 group-hover:opacity-100 ml-1"
                          onClick={() => entry.id && deleteMutation.mutate(entry.id)}
                          title="Remove"
                        >×</button>
                      </div>
                    )
                  })}
                </div>

                {/* Add button */}
                <button
                  className="mt-2 text-xs text-brand-600 hover:underline self-start"
                  onClick={() => openAddModal(date)}
                >+ Add meal</button>
              </div>
            )
          })}
        </div>
      )}

      {/* Empty state hint */}
      {!recipes || recipes.length === 0 ? (
        <p className="text-slate-500 mt-4 text-sm">
          Tip: Add recipes first in the <a href="/recipes" className="text-brand-600 underline">Recipes</a> tab before planning meals.
        </p>
      ) : null}

      {/* Add meal modal */}
      {addingDate && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50" onClick={closeModal}>
          <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-sm" onClick={e => e.stopPropagation()}>
            <h2 className="text-lg font-semibold mb-4">Add Meal for {addingDate}</h2>
            <label className="block text-sm font-medium text-slate-600 mb-1">Select Recipe</label>
            <select
              className="input mb-4"
              value={selectedRecipeId}
              onChange={e => setSelectedRecipeId(e.target.value ? +e.target.value : '')}
            >
              <option value="">-- Choose a recipe --</option>
              {(recipes ?? []).map(r => (
                <option key={r.id} value={r.id}>{r.title}</option>
              ))}
            </select>
            <div className="flex gap-3">
              <button className="btn" onClick={handleAdd} disabled={!selectedRecipeId}>Add</button>
              <button className="btn bg-slate-200 text-slate-700 hover:bg-slate-300" onClick={closeModal}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
