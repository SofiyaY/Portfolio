package com.sofiya.mealplanner.repo;

import com.sofiya.mealplanner.model.Recipe;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RecipeRepository extends JpaRepository<Recipe, Long> {}
