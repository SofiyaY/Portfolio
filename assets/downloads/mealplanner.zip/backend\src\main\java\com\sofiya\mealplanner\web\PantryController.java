package com.sofiya.mealplanner.web;

import com.sofiya.mealplanner.model.PantryItem;
import com.sofiya.mealplanner.repo.PantryRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/pantry")
public class PantryController {
    private final PantryRepository repo;
    public PantryController(PantryRepository repo) { this.repo = repo; }

    @GetMapping
    public List<PantryItem> all() { return repo.findAll(); }

    @PostMapping
    public PantryItem create(@Validated @RequestBody PantryItem p) { return repo.save(p); }

    @PutMapping("/{id}")
    public ResponseEntity<PantryItem> update(@PathVariable Long id, @Validated @RequestBody PantryItem p) {
        return repo.findById(id)
                .map(existing -> {
                    existing.setName(p.getName());
                    existing.setQuantity(p.getQuantity());
                    existing.setUnit(p.getUnit());
                    return ResponseEntity.ok(repo.save(existing));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        if (!repo.existsById(id)) return ResponseEntity.notFound().build();
        repo.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
