package com.sofiya.mealplanner.service;

import com.sofiya.mealplanner.model.*;
import com.sofiya.mealplanner.repo.MealPlanRepository;
import com.sofiya.mealplanner.repo.PantryRepository;
import com.sofiya.mealplanner.repo.RecipeRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.*;

@Service
public class GroceryService {
    private final MealPlanRepository mealPlanRepo;
    private final RecipeRepository recipeRepo;
    private final PantryRepository pantryRepo;

    public GroceryService(MealPlanRepository mealPlanRepo, RecipeRepository recipeRepo, PantryRepository pantryRepo) {
        this.mealPlanRepo = mealPlanRepo;
        this.recipeRepo = recipeRepo;
        this.pantryRepo = pantryRepo;
    }

    public List<GroceryItem> compute(LocalDate from, LocalDate to) {
        List<MealPlanEntry> entries = mealPlanRepo.findByDateBetween(from, to);
        Map<String, GroceryItem> needs = new LinkedHashMap<>();

        for (MealPlanEntry e : entries) {
            Recipe r = recipeRepo.findById(e.getRecipeId()).orElse(null);
            if (r == null) continue;
            double factor = (e.getServingsOverride() != null ? e.getServingsOverride() : r.getServingsDefault())
                    / Math.max(1.0, r.getServingsDefault());
            for (IngredientRow row : r.getIngredients()) {
                String key = normalize(row.getName()) + "|" + normalize(row.getUnit());
                double qty = row.getQuantity() * factor;
                needs.compute(key, (k, g) -> {
                    if (g == null) return new GroceryItem(row.getName(), qty, row.getUnit());
                    g.quantityNeeded += qty; return g;
                });
            }
        }

        // subtract pantry
        for (PantryItem p : pantryRepo.findAll()) {
            String key = normalize(p.getName()) + "|" + normalize(p.getUnit());
            GroceryItem g = needs.get(key);
            if (g != null) {
                g.quantityNeeded = Math.max(0, g.quantityNeeded - p.getQuantity());
            }
        }

        return new ArrayList<>(needs.values());
    }

    private String normalize(String s) { return s == null ? "" : s.trim().toLowerCase(); }

    public static class GroceryItem {
        public String name;
        public double quantityNeeded;
        public String unit;
        public GroceryItem(String name, double quantityNeeded, String unit) {
            this.name = name; this.quantityNeeded = quantityNeeded; this.unit = unit;
        }
    }
}
