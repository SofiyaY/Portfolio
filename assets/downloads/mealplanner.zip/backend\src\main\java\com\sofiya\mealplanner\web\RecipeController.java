package com.sofiya.mealplanner.web;

import com.sofiya.mealplanner.model.Recipe;
import com.sofiya.mealplanner.repo.RecipeRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/recipes")
public class RecipeController {
    private final RecipeRepository repo;
    public RecipeController(RecipeRepository repo) { this.repo = repo; }

    @GetMapping
    public List<Recipe> all() { return repo.findAll(); }

    @PostMapping
    public Recipe create(@Validated @RequestBody Recipe r) { return repo.save(r); }

    @GetMapping("/{id}")
    public ResponseEntity<Recipe> one(@PathVariable Long id) {
        return repo.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<Recipe> update(@PathVariable Long id, @Validated @RequestBody Recipe r) {
        return repo.findById(id)
                .map(existing -> {
                    existing.setTitle(r.getTitle());
                    existing.setServingsDefault(r.getServingsDefault());
                    existing.setInstructions(r.getInstructions());
                    existing.setIngredients(r.getIngredients());
                    return ResponseEntity.ok(repo.save(existing));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        if (!repo.existsById(id)) return ResponseEntity.notFound().build();
        repo.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
