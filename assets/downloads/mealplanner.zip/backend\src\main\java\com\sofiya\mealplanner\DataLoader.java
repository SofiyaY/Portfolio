package com.sofiya.mealplanner;

import com.sofiya.mealplanner.model.*;
import com.sofiya.mealplanner.repo.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class DataLoader {
    @Bean
    CommandLineRunner seed(RecipeRepository recipes, PantryRepository pantry) {
        return args -> {
            if (recipes.count() == 0) {
                Recipe pasta = new Recipe("Pasta bolognese", 2, "Kok pasta. Stek saus. Bland.");
                pasta.getIngredients().addAll(List.of(
                        new IngredientRow("pasta", 200, "g", null),
                        new IngredientRow("kjøttdeig", 300, "g", null),
                        new IngredientRow("tomatsaus", 400, "ml", null)
                ));
                recipes.save(pasta);

                Recipe salad = new Recipe("Kyllingsalat", 2, "Kutt alt. Bland.");
                salad.getIngredients().addAll(List.of(
                        new IngredientRow("kylling", 250, "g", null),
                        new IngredientRow("salat", 150, "g", null),
                        new IngredientRow("dressing", 50, "ml", null)
                ));
                recipes.save(salad);
            }

            if (pantry.count() == 0) {
                pantry.save(new PantryItem("pasta", 100, "g"));
                pantry.save(new PantryItem("tomatsaus", 100, "ml"));
            }
        };
    }
}
