import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useState } from 'react'
import { api, PantryItem } from '../shared/api'

export default function Pantry() {
  const qc = useQueryClient()
  const { data: items, isLoading, error } = useQuery({ queryKey: ['pantry'], queryFn: api.pantry.list })

  const createMutation = useMutation({
    mutationFn: api.pantry.create,
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['pantry'] }); resetForm() }
  })
  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: Omit<PantryItem, 'id'> }) => api.pantry.update(id, data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['pantry'] }); resetForm() }
  })
  const deleteMutation = useMutation({
    mutationFn: api.pantry.delete,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['pantry'] })
  })

  // Form state
  const [showForm, setShowForm] = useState(false)
  const [editId, setEditId] = useState<number | null>(null)
  const [name, setName] = useState('')
  const [quantity, setQuantity] = useState<number>(0)
  const [unit, setUnit] = useState('')

  const resetForm = () => {
    setShowForm(false)
    setEditId(null)
    setName('')
    setQuantity(0)
    setUnit('')
  }

  const openCreate = () => {
    resetForm()
    setShowForm(true)
  }

  const openEdit = (p: PantryItem) => {
    setEditId(p.id!)
    setName(p.name)
    setQuantity(p.quantity)
    setUnit(p.unit)
    setShowForm(true)
  }

  const handleSave = () => {
    const data: Omit<PantryItem, 'id'> = { name: name.trim(), quantity, unit: unit.trim() }
    if (!data.name) return alert('Name is required')
    if (editId) {
      updateMutation.mutate({ id: editId, data })
    } else {
      createMutation.mutate(data)
    }
  }

  if (isLoading) return <p className="text-slate-500">Loading pantry...</p>
  if (error) return <p className="text-red-500">Error loading pantry</p>

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-semibold">Pantry</h1>
        {!showForm && (
          <button className="btn" onClick={openCreate}>+ Add Item</button>
        )}
      </div>

      <p className="text-slate-600 mb-4 text-sm">
        Track what you already have at home. Items here will be subtracted from your grocery list.
      </p>

      {/* Form */}
      {showForm && (
        <div className="card p-6 mb-6">
          <h2 className="text-lg font-medium mb-4">{editId ? 'Edit Item' : 'Add Pantry Item'}</h2>
          <div className="grid gap-4 md:grid-cols-3">
            <div>
              <label className="block text-sm font-medium text-slate-600 mb-1">Name *</label>
              <input className="input" value={name} onChange={e => setName(e.target.value)} placeholder="e.g. Olive Oil" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-600 mb-1">Quantity</label>
              <input type="number" min={0} className="input" value={quantity || ''} onChange={e => setQuantity(+e.target.value)} />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-600 mb-1">Unit</label>
              <input className="input" value={unit} onChange={e => setUnit(e.target.value)} placeholder="e.g. ml, g, pcs" />
            </div>
          </div>
          <div className="flex gap-3 mt-4">
            <button className="btn" onClick={handleSave} disabled={createMutation.isPending || updateMutation.isPending}>
              {createMutation.isPending || updateMutation.isPending ? 'Saving...' : 'Save'}
            </button>
            <button className="btn bg-slate-200 text-slate-700 hover:bg-slate-300" onClick={resetForm}>Cancel</button>
          </div>
        </div>
      )}

      {/* List */}
      {(!items || items.length === 0) && !showForm ? (
        <div className="card p-8 text-center">
          <p className="text-slate-500 mb-4">Your pantry is empty.</p>
          <button className="btn" onClick={openCreate}>+ Add Item</button>
        </div>
      ) : (
        <ul className="card divide-y divide-slate-200">
          {(items ?? []).map(p => (
            <li key={p.id} className="p-4 flex items-center justify-between hover:bg-slate-50 transition-colors">
              <div>
                <span className="font-medium">{p.name}</span>
                <span className="text-slate-500 ml-2">{p.quantity} {p.unit}</span>
              </div>
              <div className="flex gap-2">
                <button className="text-sm text-brand-600 hover:underline" onClick={() => openEdit(p)}>Edit</button>
                <button
                  className="text-sm text-red-500 hover:underline"
                  onClick={() => { if (confirm(`Delete "${p.name}"?`)) deleteMutation.mutate(p.id!) }}
                >Delete</button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
