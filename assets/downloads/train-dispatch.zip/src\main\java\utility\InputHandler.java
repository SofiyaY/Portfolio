package utility;

import java.util.Scanner;

/**
 * The InputHandler class manages user input operations for the TrainDeparture application.
 * It handles reading user input using a Scanner object.
 * It handles reading integer, string, and LocalTime inputs.
 *
 * @author Sofiya Yasim Ibrahim Ali
 * @version 1.0
 * @since 06.10.2023
 */
public class InputHandler {

  /**
   * Fields for InputHandler class are the scanners for integers and strings.
   * They are private because they are only used in the InputHandler class.
   */
  private Scanner intScanner;
  private Scanner stringScanner;

  /**
   * Constructor for InputHandler class that initializes scanners for integers and strings.
   * The scanners are initialized in the constructor because they are needed for the InputHandler.
   */
  public InputHandler() {
    intScanner = new Scanner(System.in);
    stringScanner = new Scanner(System.in);
  }

  /**
   * Reads an integer input from the user.
   * The integer can be positive or negative.
   *
   * @return The integer input provided by the user.
   * @throws IllegalArgumentException if the input is not an integer.
   */
  public int readIntegerInput() {
    while (true) {
      // Checks if the input is an integer.
      if (intScanner.hasNextInt()) {
        // Returns the input if it is an integer.
        return intScanner.nextInt();
      } else {
        System.out.println("Invalid input! Please enter an integer.");
        // Prints an error message if the input is not an integer.
        intScanner.next();
        // Reads the next input.
      }
    }
  }

  /**
   * Reads a string input from the user.
   * The string can contain spaces.
   *
   * @return The string input provided by the user.
   * @throws IllegalArgumentException if the input is not a string.
   */
  public String readStringInput() {
    while (true) {
      // Checks if the input is a string.
      if (stringScanner.hasNextLine()) {
        // Returns the input if it is a string.
        return stringScanner.nextLine();
      } else {
        System.out.println("Invalid input! Please enter a valid string.");
        // Prints an error message if the input is not a string.
        stringScanner.next();
        // Reads the next input.
      }
    }
  }

  /**
   * Reads a time input from the user.
   * The time must be in HH:mm format.
   * If statement from this code snippet was AI-generated from ChatGPT-3.5
   * regex format from <a href="https://www.oreilly.com/library/view/regular-expressions
   -cookbook/9781449327453/ch04s06.html">...</a>
   *
   * @return The time input provided by the user.
   * @throws IllegalArgumentException if the time is not in HH:mm format.
   */
  public String readLocalTimeInput() {
    while (true) {
      String input = stringScanner.nextLine();
      /* The regex format is the LocalTime format in Java for HH:mm,
         24-hour clock with minutes and hours */
      if (input.matches("(^(2[0-3]|[01]?[0-9]):([0-5]?[0-9])$)")) {
        return input;   // Returns the input if it matches the regex format}
      } else {
        System.out.println("Invalid input! Please enter a valid time in HH:mm format.");
        // Prints an error message if the input does not match the regex format

      }
    }
  }


  /**
   * Closes the scanners.
   */
  public void closeScanners() {
    intScanner.close();
    stringScanner.close();

  }
}
