package printer;

import java.time.LocalTime;
import traindeparture.TrainDeparture;


/**
 * This class represents a Printer for the TrainDeparture application. It will handle the printing
 * functionality for the TrainRegister and TrainRegisterUI classes. It will print error messages,
 * confirmation messages, and the menu. It will also print the details of a train departure.
 *
 * @author Sofiya Yasim Ibrahim Ali
 * @version 1.0
 * @since 06.10.2023
 */


public class TrainPrinter {

  /**
   * This method prints the details of a train departure. It prints the train number, line,
   * destination, track number, departure time and delay. It will only print the delay if it is not
   * 0. It will only print the track number if it is greater than 0 ,which means that it has been
   * assigned.
   *
   * @param departure The train departure to print the details of.
   */
  public void printTrainDepartureDetails(TrainDeparture departure) {
    System.out.println("===============================");
    System.out.println("Train Departure Details:");
    System.out.println("===============================");
    System.out.println("Departs from: " + departure.getStation());
    System.out.println("Departure Time: " + departure.getDepartureTime());
    System.out.println("Line: " + departure.getLine());
    System.out.println("Train Number: " + departure.getTrainNumber());
    System.out.println("Destination: " + departure.getDestination());
    // Check if the delay is 0, print it only if it is not 0.
    if (departure.getDelay() != LocalTime.of(0, 0)) {
      System.out.println("Delay: " + departure.getDelay());
    }

    // Check if the track number is greater than 0, print it only if it is greater than 0.
    if (departure.getTrackNumber() > 0) {
      System.out.println("Track: " + departure.getTrackNumber());

    } else {
      /* If it is lower than 0, it means that the track number has not been assigned
      by the user yet. */
      System.out.println("Track: Not assigned yet.");
    }
    System.out.println("===============================");
    System.out.println();
  }


  /**
   * Prints the option to add a departure without a track number.
   */
  public void printAddWithoutTrack() {
    System.out.println();
    System.out.println("1. Add without track number");
  }

  /**
   * Prints the option to add a departure with a track number.
   */
  public void printAddWithTrack() {
    System.out.println("2. Add with track number");
  }


  /**
   * Prints the welcome message for the train departure menu.
   */
  public void printWelcomeMessage() {
    System.out.println("-----------------------------------------");
    System.out.println("Welcome to the TrainDeparture Application");
    System.out.println("-----------------------------------------");
  }

  /**
   * Prints the exit message for the train departure menu.
   */
  public void printExitMessage() {
    System.out.println("Exiting TrainDeparture Application - Have a nice day :)");
  }

  /**
   * Prints the menu for the train departure display menu. It will print the following options:
   */
  public void printMenu() {
    System.out.println("Train Departure Menu:");
    System.out.println("1. Add Train Departure");
    System.out.println("2. Search by Train Number");
    System.out.println("3. Search by Destination");
    System.out.println("4. Display All Departures");
    System.out.println("5. Assign Track to Departure");
    System.out.println("6. Add Delay to Departure");
    System.out.println("7. Update Clock");
    System.out.println("8. Exit");
    System.out.print("Enter your choice: ");
    System.out.println();
  }


  /**
   * Prints the message for invalid choice on the menu.
   */
  public void printInvalidChoiceMessage() {
    System.out.println("Invalid choice. Please enter a valid option.");
  }

  /**
   * Prints the message asking the user to enter a train number when adding a train departure.
   */
  public void printEnterTrainNumber() {
    System.out.println("Enter train number:");
  }

  /**
   * Prints the message asking the user to enter a line when adding a train departure.
   */
  public void printEnterLine() {
    System.out.println("Enter line:");
  }

  /**
   * Prints the message asking the user to enter a destination when adding a train departure.
   */
  public void printEnterDestination() {
    System.out.println("Enter destination:");
  }

  /**
   * Prints the message asking the user to enter a track number when adding a train departure.
   */

  public void printEnterTrackNumber() {
    System.out.println("Enter track number:");
  }

  /**
   * Prints the message asking the user to enter a departure time when adding a train departure.
   */
  public void printEnterDepartureTime() {
    System.out.println("Enter departure time (HH:mm):");
  }

  /**
   * Prints the message asking the user to enter a delay time when adding a train departure.
   */
  public void printEnterDelayTime() {
    System.out.println("Enter delay time (HH:mm):");
  }

  /**
   * Prints the message confirming that the train departure was added successfully when adding a
   * train departure.
   */
  public void printTrainDepartureAddedSuccessfully(int trainNumber) {
    System.out.println("New train departure with train number "
        + trainNumber + " added successfully.");
    System.out.println();
  }

  /**
   * Prints the message asking the user to enter a train number to search for.
   */
  public void printEnterTrainNumberToSearch() {
    System.out.println("Enter train number to search:");
  }

  /**
   * Prints a message indicating that the train departure was not found, if the train details do not
   * exist.
   */
  public void printTrainDepartureNotFound() {
    System.out.println("Train departure not found.");
    System.out.println();
  }

  /**
   * Prints the message asking the user to enter a destination to search for.
   */
  public void printEnterDestinationToSearch() {
    System.out.println("Enter destination to search:");
  }

  /**
   * Prints the message indicating that no matching departures were found.
   */
  public void printNoMatchingDepartures() {
    System.out.println("No matching train departures found.");
    System.out.println();
  }

  /**
   * Prints the message indicating that no train departures are available if the train register is
   * empty.
   */
  public void printNoDeparturesAvailable() {
    System.out.println("No train departures available.");
    System.out.println();
  }

  /**
   * Prints a message indicating that the train departure with the same train number already exists.
   * This means that the train number is not unique and cannot be added to the train register.
   */
  public void printSameTrainNumberExists() {
    System.out.println("Train Departure with the same train number already exists.");
    System.out.println();
  }

  /**
   * Prints a message indicating that the train departure with the same line and track number
   * already exists. This means that the line, track, and departure time are the same, and multiple
   * trains cannot drive the same route and track at the same time.
   */
  public void printSameLineAndTrackNumberExists() {
    System.out.println("Train Departure with the same line and track number at "
        + "the chosen departure time already exists.");
    System.out.println();
  }

  /**
   * Prints the message that asks the user to enter a new clock time in the format HH:mm.
   */
  public void printEnterNewClockTime() {
    System.out.print("Enter the new clock time (HH:mm): ");
  }

  /**
   * Prints the message to indicate that the clock cannot be set earlier than the current time.
   */
  public void printInvalidClockTime() {
    System.out.println("Invalid time! The new clock time cannot be earlier than the current time.");
  }

  /**
   * Prints the message to indicate that the clock has been updated.
   *
   * @param newTime The new clock time that has been set.
   */
  public void printClockUpdated(LocalTime newTime) {
    System.out.println("Clock updated successfully. New time is: " + newTime);
    System.out.println();
  }

  /**
   * Prints the message that asks the user to enter a train number to assign a track.
   */
  public void printEnterTrainNumberToAssignTrack() {
    System.out.print("Enter the train number to assign a track: ");
  }

  /**
   * Prints the message that confirms that the track has been assigned successfully.
   *
   * @param trainNumber The train number of the train departure that has been assigned a track.
   */
  public void printTrackAssignedSuccessfully(int trainNumber, int trackNumber) {
    System.out.println("Track " + trackNumber
        + " assigned successfully to train departure with train number " + trainNumber + ".");
    System.out.println();
  }

  /**
   * Prints the message that asks the user to enter a train number to add delay.
   */
  public void printEnterTrainNumberToAddDelay() {
    System.out.print("Enter the train number to add delay: ");
  }

  /**
   * Prints the message that confirms that the delay has been added successfully.
   *
   * @param trainNumber The train number of the train departure.
   * @param delay       The delay to add to the train departure.
   */
  public void printDelayAddedSuccessfully(int trainNumber, LocalTime delay) {
    System.out.println("Delay " + delay
        + " added successfully to train departure with train number " + trainNumber + ".");
    System.out.println();
  }

  /**
   * Prints a confirmation request before exiting the program. The user must enter Y to confirm that
   * they want to exit the program. If they enter N, they will be returned to the menu. If they
   * enter anything else, they will be asked to enter Y or N again. This makes sure that the user
   * does not accidentally exit the program.
   */
  public void printConfirmationExit() {
    System.out.println("Are you sure you want to exit the program? (Y/N)");
  }

}
