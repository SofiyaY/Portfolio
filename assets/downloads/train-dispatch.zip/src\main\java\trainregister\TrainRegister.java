package trainregister;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import printer.TrainPrinter;
import traindeparture.TrainDeparture;


/**
 * The TrainRegister class manages a list of TrainDeparture objects and provides a
 * menu-driven interface for managing different criteria of the train departures.
 *
 * @author Sofiya Yasim Ibrahim Ali
 * @version 1.0
 * @since 06.10.2023
 */
public class TrainRegister {

  /**
   * Fields for the TrainRegister class.
   * The trainDeparturesMap object is used to store the train departures in a HashMap.
   * The departurePrinter object is used to print different messages.
   * They are both private because they are only used in the TrainRegister class.
   * They are both final because they are permanent for the TrainRegister class.
   */
  private final HashMap<Integer, TrainDeparture> trainDeparturesMap;
  private final TrainPrinter departurePrinter;

  /**
   * Constructor for TrainRegister.
   * Initializes the train departures HashMap for storing train departures.
   * Initializes the departure printer for printing different messages.
   */
  public TrainRegister() {
    trainDeparturesMap = new HashMap<>();
    departurePrinter = new TrainPrinter();
  }

  /**
   * Adds a train departure to the list of train departures.
   * If a train departure with the same train number already exists, it will not be added.
   * If a train departure with the same line, track, and departure time already exists,
   * it will not be added.
   *
   * @param departure The train departure to add to the list of train departures.
   */
  public boolean addTrainDeparture(TrainDeparture departure) {
    LocalTime newDepartureTimeWithDelay = departure.getDepartureTime()
        .plusHours(departure.getDelay().getHour())
        .plusMinutes(departure.getDelay().getMinute());


    // Check if a train departure with the same line, track, and departure time already exists.
    for (TrainDeparture existingDeparture : trainDeparturesMap.values()) {
      LocalTime existingDepartureTimeWithDelay = existingDeparture.getDepartureTime()
          .plusHours(existingDeparture.getDelay().getHour())
          .plusMinutes(existingDeparture.getDelay().getMinute());

      /* If the line, track, and departure time are the same, new train departure will not be added.
      because multiple trains cannot drive the same route and track at the same time. */
      if (existingDeparture.getLine().equals(departure.getLine())
          && existingDeparture.getTrackNumber() == departure.getTrackNumber()
          && existingDepartureTimeWithDelay.equals(newDepartureTimeWithDelay)) {

        // Print the error message.
        departurePrinter.printSameLineAndTrackNumberExists();
        return false;
      }
    }
    // If a train departure with the same train number does not exist, add it to the HashMap.
    if (!trainDeparturesMap.containsKey(departure.getTrainNumber())) {
      trainDeparturesMap.put(departure.getTrainNumber(), departure);
      return true;
    }
    // If a train departure with the same train number already exists, do not add it to the HashMap.
    return false;
  }

  /**
   * Retrieves the list of all train departures.
   *
   * @param trainNumber The train number to search for in the list of train departures.
   *
   * @return List of all TrainDeparture objects matching the train number.
   */
  public TrainDeparture searchByTrainNumber(int trainNumber) {
    return trainDeparturesMap.getOrDefault(trainNumber, null);
  }

  /**
   * Searches for train departures based on destination.
   *
   * @param destination The destination to search for in the list of train departures.
   *
   * @return List of matching TrainDeparture objects based on destination.
   */
  public List<TrainDeparture> searchByDestination(String destination) {
    List<TrainDeparture> matchingDepartures = new ArrayList<>();
    // Iterate through the list of train departures.
    for (TrainDeparture departure : trainDeparturesMap.values()) {
      // If the destination matches, add it to the list of matching departures.
      if (departure.getDestination().equalsIgnoreCase(destination)) {
        matchingDepartures.add(departure);
      }
    }
    return matchingDepartures;
  }


  /**
    * This method retrieves the list of all train departures.
   *
   * @return List of all TrainDeparture objects in the train register.
    */
  public List<TrainDeparture> getSortedTrainDepartures() {
    List<TrainDeparture> sortedDepartures = new ArrayList<>(trainDeparturesMap.values());
    // Sort the list of train departures by departure time by using a comparator.
    sortedDepartures.sort(Comparator.comparing(TrainDeparture::getDepartureTime));
    return sortedDepartures;
  }


  /**
   * This method assigns the track to the TrainDeparture by using trainNumber.
   *
   * @param trainNumber The train number of the train departure to assign the track to.
   * @param trackNumber The track number of the train departure that is assigned.
   */
  public void assignTrackToDeparture(int trainNumber, int trackNumber) {
    TrainDeparture departure = trainDeparturesMap.get(trainNumber);

    if (departure != null) {
      // Assign the track number to the train departure if it exists.
      departure.setTrackNumber(trackNumber);
    } else {
      // Print the error message if the train departure does not exist.
      departurePrinter.printTrainDepartureNotFound();
    }
  }

  /**
   * This method adds a delay to the TrainDeparture.
   *
   * @param trainNumber The train number of the train departure to add the delay to.
   * @param delay The delay for the train departure that is added.
   */
  public void addDelayToDeparture(int trainNumber, LocalTime delay) {
    TrainDeparture departure = trainDeparturesMap.get(trainNumber);

    if (departure != null) {
      // Add the delay to the train departure if it exists.
      departure.setDelay(delay);
    } else {
      // Print the error message if the train departure does not exist.
      departurePrinter.printTrainDepartureNotFound();
    }
  }




}

