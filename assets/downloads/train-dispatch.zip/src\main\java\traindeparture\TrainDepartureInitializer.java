package traindeparture;

import java.time.LocalTime;
import trainregister.TrainRegister;

/**
 * This class initializes the existing train departures and adds them to the train schedule. It is
 * separated from the TrainRegisterUI class to make the code more readable. It is used to
 * demonstrate the functionality of the train departures.
 *
 * @author Sofiya Yasim Ibrahim Ali
 * @version 1.0
 * @since 06.10.2023
 */
public class TrainDepartureInitializer {

  /**
   * Initializes the train departures and adds them to the train schedule. This method is called
   * from the TrainRegisterUI class. departure4 is final because the value remains constant, as
   * recommended by Checkstyle.
   *
   * @param trainRegister The train register to add the train departures to.
   */
  public void initializeAndAddDepartures(TrainRegister trainRegister) {
    TrainDeparture departure1 = new TrainDeparture(3012, "L1",
        "Levanger stasjon", 1, LocalTime.of(13, 0), LocalTime.of(0, 5));
    TrainDeparture departure2 = new TrainDeparture(203, "L2",
        "Trondheim S", 2, LocalTime.of(15, 30), LocalTime.of(0, 0));
    TrainDeparture departure3 = new TrainDeparture(104, "L3",
        "Malvik", 3, LocalTime.of(19, 45), LocalTime.of(0, 10));
    final TrainDeparture departure4 = new TrainDeparture(45, "L4",
        "Trondheim lufthavn", 4, LocalTime.of(23, 10), LocalTime.of(0, 3));

    addDeparture(trainRegister, departure1);
    addDeparture(trainRegister, departure2);
    addDeparture(trainRegister, departure3);
    addDeparture(trainRegister, departure4);
  }

  /**
   * Adds a train departure to the list of train departures. If a train departure with the same
   * train number already exists, it will not be added.
   *
   * @param trainRegister The train register to add the train departure to.
   * @param departure     The train departure to add to the list of train departures.
   */
  private void addDeparture(TrainRegister trainRegister, TrainDeparture departure) {
    trainRegister.addTrainDeparture(departure);
  }
}