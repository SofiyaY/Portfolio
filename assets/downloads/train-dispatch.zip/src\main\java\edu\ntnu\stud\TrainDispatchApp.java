package edu.ntnu.stud;

import trainregister.TrainRegisterUI;

/**
 * This is the main class for the train dispatch application.
 *
 * @author Sofiya Yasim Ibrahim Ali
 * @version 1.0
 * @since 06.10.2023
 */
public class TrainDispatchApp {

  /**
   * The main method that starts the train dispatch application.
   *
   * @param args The command line arguments.
   */
  public static void main(String[] args) {
    TrainRegisterUI trainregister = new TrainRegisterUI();
    trainregister.start();

  }

}