package trainregister;

import printer.TrainPrinter;
import utility.InputHandler;
import traindeparture.TrainDepartureInitializer;
import traindeparture.TrainDeparture;

import java.time.LocalTime;
import java.util.List;

  /**
   * TrainManager class manages the user interface for the train schedule.
   * This class interacts with TrainManager by displaying a menu and reading user input.
   * This class manages the program flow for the train schedule.
   *
   * @author Sofiya Yasim Ibrahim Ali
   * @version 1.0
   * @since 06.10.2023
   */
  public class TrainRegisterUI {

    /**
     * Fields for Trainmanager.
     * Initializes the train schedule, input handler, scanner and departure printer.
     * Initializes the initializer for the already existing train departures.
     * Initializes the current time.
     */
    private TrainDepartureInitializer initializer;
    private TrainRegister register;
    private InputHandler inputHandler;
    private TrainPrinter departurePrinter;
    private LocalTime currentTime;

    /**
     * Constructor for TrainManager.
     * Initializes the train schedule, input handler, scanner and departure printer.
     * Initializes the initializer for the already existing train departures.
     * Initializes the current time.
     */
    public TrainRegisterUI() {
      register = new TrainRegister();
      inputHandler = new InputHandler();
      initializer = new TrainDepartureInitializer();
      initializer.initializeAndAddDepartures(register);
      departurePrinter = new TrainPrinter();
      currentTime = LocalTime.now();
    }

    /**
     * Starts the train schedule app and displays the menu.
     */
    public void start() {
      welcome();
      int choice = 0;
      while (choice != 9) { // Oppdatert antall valg
        displayMenu();
        choice = inputHandler.readIntegerInput();

        switch (choice) {
          case 1:
            addTrainDepartureFromInput();
            break;
          case 2:
            searchByTrainNumberFromInput();
            break;
          case 3:
            searchByDestinationFromInput();
            break;
          case 4:
            displayAllTrainDepartures();
            break;
          case 5:
            assignTrackToDepartureFromInput();
            break;
          case 6:
            addDelayToDepartureFromInput();
            break;
          case 7:
            updateClock();
            break;
          case 8:
            exit();
            break;
          default:
            departurePrinter.printInvalidChoiceMessage();
            break;
        }
      }
      inputHandler.closeScanners();
    }

    /**
     * Displays the menu for the train schedule.
     */
    public void displayMenu() {
     departurePrinter.printMenu();
    }

    /**
     * Adds a new train departure based on user input.
     * The train departure is then added to the train schedule.
     */
      private void addTrainDepartureFromInput() {
        departurePrinter.printEnterTrainNumber();
        int trainNumber = inputHandler.readIntegerInput();

        departurePrinter.printEnterLine();
        String line = inputHandler.readStringInput();

        departurePrinter.printEnterDestination();
        String destination = inputHandler.readStringInput();

        departurePrinter.printAddWithoutTrack();
        departurePrinter.printAddWithTrack();

        // If the user chooses not to enter a track number, the track number is set to -1.
        // If the user chooses to enter a track number, the track number is set to the user input.
        int trackNumber = -1;
        int userChoice = inputHandler.readIntegerInput();

        if (userChoice == 1) {

          trackNumber = -1;
        } else if (userChoice == 2) {

          departurePrinter.printEnterTrackNumber();
          trackNumber = inputHandler.readIntegerInput();

        } else {
          departurePrinter.printInvalidChoiceMessage();
          return;
        }

        departurePrinter.printEnterDepartureTime();
        LocalTime departureTime = LocalTime.parse(inputHandler.readLocalTimeInput());

        departurePrinter.printEnterDelayTime();
        LocalTime delay = LocalTime.parse(inputHandler.readLocalTimeInput());


        TrainDeparture newDeparture = new TrainDeparture(trainNumber, line, destination, trackNumber, departureTime, delay);
        boolean addedSuccessfully = register.addTrainDeparture(newDeparture);

        if (addedSuccessfully) {
          departurePrinter.printTrainDepartureAddedSuccessfully(trainNumber);
        } else {
          departurePrinter.printSameTrainNumberExists();
        }
      }

    /**
     * Searches for a train departure based on train number given by the user.
     */
    private void searchByTrainNumberFromInput() {
      departurePrinter.printEnterTrainNumberToSearch();
      int trainNumber = inputHandler.readIntegerInput();

      TrainDeparture foundDeparture = register.searchByTrainNumber(trainNumber);
      if (foundDeparture != null) {
        displayTrainDepartureDetails(foundDeparture);
      } else {
        departurePrinter.printTrainDepartureNotFound();
      }
    }

    /**
     * Searches for train departures based on destination given by the user.
     */
    private void searchByDestinationFromInput() {
      departurePrinter.printEnterDestinationToSearch();
      String destination = inputHandler.readStringInput();

      List<TrainDeparture> matchingDepartures = register.searchByDestination(destination);
      if (!matchingDepartures.isEmpty()) {
        for (TrainDeparture departure : matchingDepartures) {
          displayTrainDepartureDetails(departure);
        }
      } else {
        departurePrinter.printNoMatchingDepartures();
      }
    }


    /**
     * Shows the details of a train departure.
     *
     * @param departure Train departure to display details for.
     */
    private void displayTrainDepartureDetails(TrainDeparture departure) {
      departurePrinter.printTrainDepartureDetails(departure);
    }

    /**
     * Displays the already existing train departures.
     * Including the ones that have been added by the user.
     * If no train departures exist, a message is displayed.
     * If train departures exist, the details of each train departure is displayed.
     */
    private void displayAllTrainDepartures() {
      List<TrainDeparture> allDepartures = register.getSortedTrainDepartures();
      boolean foundDepartures = false;

      for (TrainDeparture departure : allDepartures) {
        LocalTime actualDepartureTime = departure.getDepartureTime().plusHours(departure.getDelay().getHour())
            .plusMinutes(departure.getDelay().getMinute());

        if (!actualDepartureTime.isBefore(currentTime)) {
          // Only display departures after the current time
          displayTrainDepartureDetails(departure);
          foundDepartures = true;
        }
    }
      if(!foundDepartures){
        departurePrinter.printNoDeparturesAvailable();

      }
    }

    /**
     * Updates the clock time based on user input.
     * The clock time is updated to the new time if the new time is after the current time.
     */
    public void updateClock() {
      departurePrinter.printEnterNewClockTime();
      LocalTime newTime = LocalTime.parse(inputHandler.readLocalTimeInput());

      if (newTime.isAfter(currentTime)) {
        currentTime = newTime;
        departurePrinter.printClockUpdated(newTime);

      } else {
        departurePrinter.printInvalidClockTime();
      }
    }

    /**
     * Assigns a track to a train departure based on user input.
     * The track is assigned to the train departure based on the train number.
     */
    public void assignTrackToDepartureFromInput() {
      departurePrinter.printEnterTrainNumberToAssignTrack();
      int trainNumber = inputHandler.readIntegerInput();

      departurePrinter.printEnterTrackNumber();
      int trackNumber = inputHandler.readIntegerInput();

      register.assignTrackToDeparture(trainNumber, trackNumber);
      departurePrinter.printTrackAssignedSuccessfully(trainNumber, trackNumber);
    }

    /**
     * Adds a delay to a train departure based on user input.
     * The delay is added to the departure time of the train departure.
     */

    public void addDelayToDepartureFromInput() {
      departurePrinter.printEnterTrainNumberToAddDelay();
      int trainNumber = inputHandler.readIntegerInput();

      departurePrinter.printEnterDelayTime();
      LocalTime delay = LocalTime.parse(inputHandler.readLocalTimeInput());

      register.addDelayToDeparture(trainNumber, delay);
      //if delay is added successfully print message
      departurePrinter.printDelayAddedSuccessfully(trainNumber, delay);
    }
    /**
     * Displays a welcome message for the train schedule before displaying the menu.
     */
    public void welcome() {
      departurePrinter.printWelcomeMessage();
    }

    /**
     * Displays a goodbye message for the train schedule before exiting the program.
     */
    public void exit() {
      departurePrinter.printConfirmationExit();
      String userInput = inputHandler.readStringInput();
      if (userInput.equalsIgnoreCase("Y")) {
        departurePrinter.printExitMessage();
        //Exit the program
        System.exit(0);
      } else if(userInput.equalsIgnoreCase("N")) {
        start();
        //Start the program again
      } else {
        departurePrinter.printInvalidChoiceMessage();
        //Ask the user to enter a valid option
      }

      System.exit(0);
    }
  }


