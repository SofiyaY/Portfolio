package trainregister;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalTime;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import traindeparture.TrainDeparture;

/**
 * The TrainRegisterTest class tests the methods in the TrainRegister class. This class tests the
 * methods in the TrainRegister class to make sure they work as expected.
 *
 * @author Sofiya Yasim Ibrahim Ali
 * @version 1.0
 * @since 06.10.2023
 */


class TrainRegisterTest {

  /**
   * The trainRegister object is used to test the methods in the TrainRegister class. The
   * testDeparture object is used to test the methods in the TrainRegister class. They are both
   * private because they are only used in the TrainRegisterTest class.
   */
  private TrainRegister trainRegister;
  private TrainDeparture testDeparture;

  /**
   * This method is called before each test. It creates a new TrainRegister object. The
   * testDeparture object is used to test the methods in the TrainRegister class. LocalTime is used
   * to set the departure time and delay.
   */
  @BeforeEach
  void setUp() {
    trainRegister = new TrainRegister();
    LocalTime departureTime = LocalTime.of(12, 0);
    LocalTime delay = LocalTime.of(0, 15);
    testDeparture = new TrainDeparture(2, "L3", "Madrid", 1, departureTime, delay);
  }

  /**
   * This method tests if the addTrainDeparture method adds a train departure to the list of train
   * departures if there already exists a train departure with the same train number. The test
   * searches for a train departure with destination Madrid and checks if there is one train
   * departure with destination Madrid. It should be only one train departure with destination
   * Madrid.
   */

  @Test
  void addTrainDeparturePositive() {
    trainRegister.addTrainDeparture(testDeparture);
    TrainDeparture duplicatedDeparture = new TrainDeparture(2, "L3", "Madrid",
        1, LocalTime.of(12, 0), LocalTime.of(0, 15));
    trainRegister.addTrainDeparture(duplicatedDeparture);

    List<TrainDeparture> departures = trainRegister.searchByDestination("Madrid");
    assertEquals(1, departures.size());
  }

  /**
   * This method tests if the addTrainDeparture method does not add a train departure to the list of
   * train departures if there already exists a train departure with the same train number. The test
   * searches for a train departure with destination Madrid and checks if there are not two train
   * departures with destination Madrid. There should not be two train departures with destination
   * Madrid.
   */
  @Test
  void addTrainDepartureNegative() {
    // Adds the test departure to the train register.
    trainRegister.addTrainDeparture(testDeparture);

    // Adds a train departure with the same train number as the test departure.
    TrainDeparture duplicatedDeparture = new TrainDeparture(2, "L3", "Madrid",
        1, LocalTime.of(12, 0), LocalTime.of(0, 15));
    trainRegister.addTrainDeparture(duplicatedDeparture);

    // Checks if there are two train departures with destination Madrid.
    List<TrainDeparture> departures = trainRegister.searchByDestination("Madrid");
    assertNotEquals(2, departures.size());
  }

  /**
   * This method tests if the searchByTrainNumber method returns the correct train departure. The
   * test searches for a train departure with train number 2 and checks if it matches the test
   * departure. It should match the test departure.
   */
  @Test
  void searchByTrainNumberPositive() {
    trainRegister.addTrainDeparture(testDeparture);
    assertEquals(testDeparture, trainRegister.searchByTrainNumber(2));
  }

  /**
   * This method tests if the searchByTrainNumber method does not return the correct train
   * departure. The test searches for a train departure with train number 3 and checks if it does
   * not match the test departure. It should not match the test departure.
   */
  @Test
  void searchByTrainNumberNegative() {
    trainRegister.addTrainDeparture(testDeparture);
    assertNotEquals(testDeparture, trainRegister.searchByTrainNumber(3));
  }

  /**
   * This method tests if the searchByDestination method returns the correct train departure. The
   * test searches for a train departure with destination Madrid and checks if it matches the test
   * departure. It should match the test departure.
   */
  @Test
  void searchByDestinationPositive() {
    trainRegister.addTrainDeparture(testDeparture);
    List<TrainDeparture> departures = trainRegister.searchByDestination("Madrid");
    assertEquals(1, departures.size());
  }

  /**
   * This method tests if the searchByDestination method does not return the correct train
   * departure. The test searches for a train departure with destination Barcelona and checks if it
   * does not match the test departure. It should not match the test departure.
   */
  @Test
  void searchByDestinationNegative() {
    trainRegister.addTrainDeparture(testDeparture);
    List<TrainDeparture> departures = trainRegister.searchByDestination("Barcelona");
    assertNotEquals(1, departures.size());
  }

  /**
   * This method tests if the getSortedTrainDepartures method returns the train departures sorted
   * correctly. The test adds 1 train departure to the train register and checks if the size of the
   * list of train departures is 1. It should be 1.
   */
  @Test
  void getSortedTrainDeparturesPositive() {
    trainRegister.addTrainDeparture(testDeparture);
    // Gets the list of train departures
    List<TrainDeparture> departures = trainRegister.getSortedTrainDepartures();
    // Checks if the list of train departures is not null.
    assertNotNull(departures);
    // Checks if the size of the list of train departures is 1.
    assertEquals(1, departures.size());
  }

  /**
   * This method tests if the getSortedTrainDepartures method does not return the train departures
   * sorted correctly. The test adds 1 train departure to the train register and checks if the size
   * of the list of train departures is not 1. It should not be 1.
   */
  @Test
  void getSortedTrainDeparturesNegative() {
    List<TrainDeparture> departures = trainRegister.getSortedTrainDepartures();
    assertNotNull(departures);
    assertNotEquals(1, departures.size());
  }

  /**
   * This method tests if the assignTrackToDeparture method assigns the correct track number to the
   * train departure. The test adds a train departure to the train register and assigns the track
   * number 2 to it. It then checks if the track number of the train departure is 2. It should be
   * 2.
   */
  @Test
  void assignTrackToDeparturePositive() {
    trainRegister.addTrainDeparture(testDeparture);
    // Assigns a track number to a train departure with train number 2.
    int trackNumber = 2;
    trainRegister.assignTrackToDeparture(2, trackNumber);

    // Checks if the track number of the train departure with train number 2 is 2.
    TrainDeparture departure = trainRegister.searchByTrainNumber(2);
    assertEquals(trackNumber, departure.getTrackNumber());
  }

  /**
   * This method tests if the assignTrackToDeparture method does not assign the correct track number
   * to the train departure. The test adds a train departure to the train register and assigns the
   * track number 2 to it. It then checks if the track number of the train departure is not 3. It
   * should not be 3.
   */
  @Test
  void assignTrackToDepartureNegative() {
    // Adds a train departure to the train register.
    trainRegister.addTrainDeparture(testDeparture);
    int trackNumber = 2;

    // Checks if the departure with train number 3 does not exist before assigning track number.
    TrainDeparture departure = trainRegister.searchByTrainNumber(3);
    assertEquals(null, departure);

    // Assigns a track number to a train departure with train number 3.
    trainRegister.assignTrackToDeparture(3, trackNumber);

    // Confirms that the track number was not assigned to the train departure with train number 3.
    departure = trainRegister.searchByTrainNumber(3);
    assertEquals(null, departure);
  }

  /**
   * This method tests if the addDelayToDeparture method adds the correct delay to the train
   * departure.
   */
  @Test
  void addDelayToDeparturePositive() {
    // Adds a train departure to the train register.
    trainRegister.addTrainDeparture(testDeparture);
    LocalTime additionalDelay = LocalTime.of(0, 5);

    // Gets the train departure with train number 2 and verifies that it exists.
    TrainDeparture departure = trainRegister.searchByTrainNumber(2);
    assertNotNull(departure);

    // Adds a delay to the train departure with train number 2 and checks if it matches the expected delay.
    trainRegister.addDelayToDeparture(2, additionalDelay);
    departure = trainRegister.searchByTrainNumber(2);
    assertNotEquals(null, departure);
  }

  /**
   * This method tests if the addDelayToDeparture method does not add the correct delay to the train
   * departure.
   */
  @Test
  void addDelayToDepartureNegative() {

    trainRegister.addTrainDeparture(testDeparture);
    LocalTime additionalDelay = LocalTime.of(0, 5);

    TrainDeparture departure = trainRegister.searchByTrainNumber(3);
    assertNull(departure);

    trainRegister.addDelayToDeparture(3, additionalDelay);
    departure = trainRegister.searchByTrainNumber(3);
    assertEquals(null, departure);
  }

}