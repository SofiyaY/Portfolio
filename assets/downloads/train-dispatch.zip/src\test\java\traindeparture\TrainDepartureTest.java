package traindeparture;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import java.time.LocalTime;

/**
 * The TrainDepartureTest class tests the TrainDeparture class. This class tests the methods in the
 * TrainDeparture class to make sure they work as expected.
 *
 * @author Sofiya Yasim Ibrahim Ali
 * @version 1.0
 * @since 06.10.2023
 */
class TrainDepartureTest {

  /**
   * The trainDepartureTest object is used to test the methods in the TrainDeparture class.
   */
  TrainDeparture trainDepartureTest;

  /**
   * This method is called before each test. It creates a new TrainDeparture object. LocalTime is
   * used to set the departure time and delay.
   */
  @BeforeEach
  void setUp() {
    LocalTime departureTime = LocalTime.of(12, 0);
    LocalTime delay = LocalTime.of(0, 15);
    trainDepartureTest = new TrainDeparture(2, "L3", "Madrid", 1, departureTime, delay);
  }

  /**
   * This method tests if the train number is returned correctly in the TrainDeparture class.
   */
  @Test
  void PositiveGetTrainNumber() {
    assertEquals(2, trainDepartureTest.getTrainNumber());
  }

  /**
   * This method tests if the line is returned correctly in the TrainDeparture class.
   */
  @Test
  void PositiveGetLine() {
    assertEquals("L3", trainDepartureTest.getLine());
  }

  /**
   * This method tests if the track number is returned correctly in the TrainDeparture class.
   */
  @Test
  void PositiveGetTrackNumber() {
    assertEquals(1, trainDepartureTest.getTrackNumber());

  }

  /**
   * This method tests if the destination is returned correctly in the TrainDeparture class.
   */
  @Test
  void PositiveGetDestination() {
    assertEquals("Madrid", trainDepartureTest.getDestination());
  }

  /**
   * This method tests if the departure time is returned correctly in the TrainDeparture class.
   */
  @Test
  void PositiveGetDepartureTime() {
    assertEquals(LocalTime.of(12, 0), trainDepartureTest.getDepartureTime());
  }

  /**
   * This method tests if the delay is returned correctly in the TrainDeparture class.
   */
  @Test
  void PositiveGetDelay() {
    assertEquals(LocalTime.of(0, 15), trainDepartureTest.getDelay());
  }

  /**
   * This tests if the train number is not returned correctly in the TrainDeparture class.
   */
  @Test
  void NegativeGetTrainNumber() {
    assertNotEquals(3, trainDepartureTest.getTrainNumber());
  }

  /**
   * This tests if the line is not returned correctly in the TrainDeparture class.
   */
  @Test
  void NegativeGetLine() {
    assertNotEquals("L4", trainDepartureTest.getLine());
  }

  /**
   * This tests if the track number is not returned correctly in the TrainDeparture class.
   */
  @Test
  void NegativeGetTrackNumber() {
    assertNotEquals(2, trainDepartureTest.getTrackNumber());
  }

  /**
   * This tests if the destination is not returned correctly in the TrainDeparture class.
   */
  @Test
  void NegativeGetDestination() {
    assertNotEquals("Paris", trainDepartureTest.getDestination());
  }

  /**
   * This tests if the departure time is not returned correctly in the TrainDeparture class.
   */
  @Test
  void NegativeGetDepartureTime() {
    assertNotEquals(LocalTime.of(13, 0), trainDepartureTest.getDepartureTime());
  }

  /**
   * This tests if the delay is not returned correctly in the TrainDeparture class.
   */
  @Test
  void NegativeGetDelay() {
    assertNotEquals(LocalTime.of(0, 30), trainDepartureTest.getDelay());
  }

  /**
   * This method tests if the train number is set correctly in the TrainDeparture class. The train
   * number is set to 2, and the test checks if the train number is 2.
   */
  @Test
  void PositiveSetTrainNumber() {
    trainDepartureTest.setTrainNumber(2);
    assertEquals(2, trainDepartureTest.getTrainNumber());
  }

  /**
   * This method tests if the line is set correctly in the TrainDeparture class. The line is set to
   * L4, and the test checks if the line is L4.
   */
  @Test
  void PositiveSetLine() {
    trainDepartureTest.setLine("L4");
    assertEquals("L4", trainDepartureTest.getLine());
  }

  /**
   * This method tests if the destination is set correctly in the TrainDeparture class. The
   * destination is set to Paris, and the test checks if the destination is Paris.
   */
  @Test
  void PositiveSetDestination() {
    trainDepartureTest.setDestination("Paris");
    assertEquals("Paris", trainDepartureTest.getDestination());
  }

  /**
   * This method tests if the track number is set correctly in the TrainDeparture class. The track
   * number is set to 2, and the test checks if the track number is 2.
   */
  @Test
  void PositiveSetTrackNumber() {
    trainDepartureTest.setTrackNumber(2);
    assertEquals(2, trainDepartureTest.getTrackNumber());
  }

  /**
   * This method tests if the departure time is set correctly in the TrainDeparture class. The
   * departure time is set to 13:00, and the test checks if the departure time is 13:00.
   */
  @Test
  void PositiveSetDepartureTime() {
    trainDepartureTest.setDepartureTime(LocalTime.of(13, 0));
    assertEquals(LocalTime.of(13, 0), trainDepartureTest.getDepartureTime());
  }

  /**
   * This method tests if the delay is set correctly in the TrainDeparture class. The delay is set
   * to 30 minutes, and the test checks if the delay is 30 minutes.
   */
  @Test
  void PositiveSetDelay() {
    LocalTime newDelay = LocalTime.of(0, 30); // Set a new delay of 30 minutes
    trainDepartureTest.setDelay(newDelay);
    assertEquals(newDelay, trainDepartureTest.getDelay());
  }

  /**
   * This method tests if setting an invalid train number results in the departure being invalid.
   */
  @Test
  void PositiveSetInvalidTrainNumber() {
    trainDepartureTest.setTrainNumber(2); // Sets an invalid train number
    assertTrue(trainDepartureTest.isValid());
  }

  /**
   * This method tests if the train number is not set correctly in the TrainDeparture class. The
   * train number is set to 2, and the test checks if the train number is not 3.
   */
  @Test
  void NegativeSetTrainNumber() {
    trainDepartureTest.setTrainNumber(2);
    assertNotEquals(3, trainDepartureTest.getTrainNumber());
  }

  /**
   * This method tests if the line is not set correctly in the TrainDeparture class. The line is set
   * to L4, and the test checks if the line is not L3.
   */
  @Test
  void NegativeSetLine() {
    trainDepartureTest.setLine("L4");
    assertNotEquals("L3", trainDepartureTest.getLine());
  }

  /**
   * This method tests if the destination is not set correctly in the TrainDeparture class. The
   * destination is set to Paris, and the test checks if the destination is not Madrid.
   */
  @Test
  void NegativeSetDestination() {
    trainDepartureTest.setDestination("Paris");
    assertNotEquals("Madrid", trainDepartureTest.getDestination());
  }

  /**
   * This method tests if the track number is not set correctly in the TrainDeparture class. The
   * track number is set to 2, and the test checks if the track number is not 1.
   */
  @Test
  void NegativeSetTrackNumber() {
    trainDepartureTest.setTrackNumber(2);
    assertNotEquals(1, trainDepartureTest.getTrackNumber());
  }

  /**
   * This method tests if the departure time is not set correctly in the TrainDeparture class. The
   * departure time is set to 13:00, and the test checks if the departure time is not 12:00.
   */
  @Test
  void NegativeSetDepartureTime() {
    trainDepartureTest.setDepartureTime(LocalTime.of(13, 0));
    assertNotEquals(LocalTime.of(12, 0), trainDepartureTest.getDepartureTime());
  }

  /**
   * This method tests if the delay is not set correctly in the TrainDeparture class. The original
   * delay is set to 15 minutes, and the new delay is set to 30 minutes. The test checks if the new
   * delay is not 15 minutes.
   */
  @Test
  void NegativeSetDelay() {
    LocalTime originalDelay = LocalTime.of(0, 15);
    trainDepartureTest.setDelay(originalDelay);

    LocalTime newDelay = LocalTime.of(0, 30);
    trainDepartureTest.setDelay(newDelay);
    assertNotEquals(originalDelay, trainDepartureTest.getDelay());
  }


  /**
   * This method tests if setting an invalid train number results in the departure being invalid.
   */
  @Test
  void NegativeSetInvalidTrainNumber() {
    trainDepartureTest.setTrainNumber(-1); // Set an invalid train number
    assertFalse(trainDepartureTest.isValid());
  }


}