package traindeparture;

import java.time.LocalTime;


/**
 * This class represents train departures and provides methods to manage train departures. The train
 * departure is represented by a train number, tracks, destination, and departure time.
 *
 * @author Sofiya Yasim Ibrahim Ali
 * @version 1.0
 * @since 06.10.2023
 */
public class TrainDeparture {

  /**
   * Fields for the TrainDeparture class include train number, tracks, destination, departure time,
   * delay, and station. These are going to be used to create a train departure. isValid is used to
   * check if the different fields are valid. The station is final because it is permanent for all
   * train departures. The station is static because the value is the same for every instance of the
   * class.
   */
  private int trainNumber;
  private String line;
  private String destination;
  private int trackNumber;
  private LocalTime departureTime;
  private LocalTime delay;
  private boolean isValid = true;
  private static final String station = "Stjørdal stasjon";


  /**
   * This is the constructor for the TrainDeparture class. It takes a specified train number,
   * tracks, destination, and departure time. This constructor is used to create a train departure
   * object.
   *
   * @param trainNumber   The train number is represented by a String and is unique.
   * @param line          The line is represented by a String and is a route or train line.
   * @param destination   The destination is represented by a String and is the final stop.
   * @param trackNumber   The track is represented by a String and is the assigned track number.
   * @param departureTime The departure time is represented by LocalTime and is the time of the
   *                      train departure.
   * @param delay         The delay time is represented by LocalTime and is the delay of the train
   *                      departure.
   */
  public TrainDeparture(int trainNumber, String line, String destination, int trackNumber,
      LocalTime departureTime, LocalTime delay) {
    setTrainNumber(trainNumber);
    setLine(line);
    setDestination(destination);
    setTrackNumber(trackNumber);
    setDepartureTime(departureTime);
    setDelay(delay);
  }

  /**
   * This method checks if the different fields are valid.
   *
   * @return isValid as a boolean for validity of the different fields.
   */
  public boolean isValid() {
    return isValid;
  }

  /**
   * Get the train number of the train departure.
   *
   * @return train number as a String for the train departure.
   */
  public int getTrainNumber() {
    return trainNumber;
  }

  /**
   * Get the tracks of the train departure.
   *
   * @return tracks as a String for the train departure.
   */
  public String getLine() {
    return line;
  }

  /**
   * Get the destination of the train departure.
   *
   * @return destination as a String for the train departure.
   */
  public String getDestination() {
    return destination;
  }

  /**
   * Get the tracks of the train departure.
   *
   * @return tracks as a String for the train departure.
   */
  public int getTrackNumber() {
    return trackNumber;
  }

  /**
   * Get the departure time of the train departure.
   *
   * @return departure time as a LocalTime for the train departure.
   */
  public LocalTime getDepartureTime() {
    return departureTime;
  }

  /**
   * Get the delay time of the train departure.
   *
   * @return delay time as a LocalTime for the train departure.
   */
  public LocalTime getDelay() {
    return delay;
  }

  /**
   * Get the permanent station of the train departure.
   *
   * @return station as a String for the train departure.
   */
  public String getStation() {
    return station;
  }

  /**
   * Set the train number of the train departure. If the train number is below 0, the train
   * departure is not valid.
   *
   * @param trainNumber The train number as a String for the train departure.
   */

  public void setTrainNumber(int trainNumber) {
    if (trainNumber > 0) {
      this.trainNumber = trainNumber;
    } else {
      isValid = false;
    }
  }

  /**
   * Set the line of the train departure. If the line is null, the train departure is not valid.
   *
   * @param line The line as a String for the train departure.
   */
  public void setLine(String line) {
    if (line != null) {
      this.line = line;
    } else {
      isValid = false;
    }
  }


  /**
   * Set the destination of the train departure. If the destination is null, the train departure is
   * not valid.
   *
   * @param destination The destination as a String for the train departure.
   */

  public void setDestination(String destination) {
    if (destination != null) {
      this.destination = destination;
    } else {
      isValid = false;
    }
  }

  /**
   * Set the track of the train departure. If the track is 0, the train departure is not valid.
   *
   * @param trackNumber The trackNumber as a String for the train departure.
   */
  public void setTrackNumber(int trackNumber) {
    if (trackNumber != 0) {
      this.trackNumber = trackNumber;
    } else {
      isValid = false;
    }
  }

  /**
   * Set the departure time of the train departure. If the departure time is null, the train
   * departure is not valid.
   *
   * @param departureTime The departure time as a LocalTime for the train departure.
   */
  public void setDepartureTime(LocalTime departureTime) {
    if (departureTime != null) {
      this.departureTime = departureTime;
    } else {
      isValid = false;
    }
  }

  /**
   * Set the delay time for the train departure. If the delay time is null, the train departure is
   * not valid.
   *
   * @param delay The delay time as a LocalTime for the train departure.
   */

  public void setDelay(LocalTime delay) {
    if (delay != null) {
      this.delay = delay;
    } else {
      isValid = false;
    }
  }


}
