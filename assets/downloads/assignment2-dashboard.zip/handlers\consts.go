package handlers //

const REST_COUNTRIES_API = "http://129.241.150.113:8080/v3.1/alpha" // alpha was forgotten in git
const OPEN_METEO_API = "https://api.open-meteo.com/v1/forecast?"
const CURRENCY_API = "http://129.241.150.113:9090/currency"

const FirestoreCollection = "dashboards"
const FirestoreNotifications = "webhooks"
