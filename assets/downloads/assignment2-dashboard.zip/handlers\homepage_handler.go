package handlers

// Edited by all members

import (
	"fmt"
	"net/http"
)

/*
User friendly (readable) homepage.
Katerina R. & Sofiya Y. I. Ali
*/
func HomepageHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		http.Error(w, "Method not allowed, use GET", http.StatusMethodNotAllowed)
		return
	}

	w.Header().Set("Content-Type", "text/html; charset=utf-8")

	fmt.Fprintln(w, `<!DOCTYPE html>
	<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>Dashboard Notification Service</title>
		<style>
			body { font-family: Arial, sans-serif; margin: 2rem; background-color: #f9f9f9; }
			h1 { color: #333; }
			ul { line-height: 1.8; }
			code { background: #eee; padding: 2px 4px; border-radius: 4px; }
		</style>
	</head>
	<body>
		<h1>Welcome to the Dashboard Notification Service!</h1>
		<p>Use the following endpoints to interact with the API:</p>
		<ul>
			<li><code>GET /dashboard/v1/registrations/</code> -> List all dashboards</li>
			<li><code>POST /dashboard/v1/registrations/</code> -> Register a new dashboard (JSON body)</li>
			<li><code>GET /dashboard/v1/registrations/{id}</code> -> Get a specific dashboard</li>
			<li><code>PUT /dashboard/v1/registrations/{id}</code> -> Replace a dashboard (JSON body)</li>
			<li><code>DELETE /dashboard/v1/registrations/{id}</code> -> Delete a dashboard</li>
			<br>
			<li><code>GET /dashboard/v1/dashboards/{id}</code> -> Retrieve a specific populated dashboard</li>
			<br>
			<li><code>POST /dashboard/v1/notifications/</code> -> Register a webhook (JSON body)</li>
			<li><code>GET /dashboard/v1/notifications/</code> -> List all webhooks</li>
			<li><code>GET /dashboard/v1/notifications/{id}</code> -> Get webhook by ID</li>
			<li><code>DELETE /dashboard/v1/notifications/{id}</code> -> Delete webhook by ID</li>
			<br>
			<li><code>GET /dashboard/v1/status/</code> -> Monitore service availability</li>
		</ul>
		<p>You can use <strong>Postman</strong> to test these endpoints.</p>
	</body>
	</html>`)
}
