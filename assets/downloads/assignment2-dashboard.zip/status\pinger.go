package status

//Written by Katharina

import (
	"net/http"
	"time"
)

// PingURL checks the status of a URL and returns the HTTP status code. And, if the URL is unreachable, it returns 0.
func PingURL(url string) int {
	client := &http.Client{Timeout: time.Second * 3}
	resp, err := client.Get(url)
	if err != nil {
		return 0
	}

	// Check if the response is nil
	defer resp.Body.Close()
	return resp.StatusCode
}
