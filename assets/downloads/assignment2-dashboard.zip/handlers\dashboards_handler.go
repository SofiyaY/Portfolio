package handlers

// Written by Katerina R.

import (
	"Assigment2/structs"
	"cloud.google.com/go/firestore"
	"context"
	"encoding/json"
	_ "errors"
	"fmt"
	_ "fmt"
	_ "google.golang.org/api/iterator"
	"io"
	"log"
	"net/http"
	"strings"
	"time"
)

/*
Helper function getCountryInfo API call for the country info to populate the dashboard with.
Katerina R.
*/
func getCountryInfo(countryCode string) (string, structs.PopulatedCoordinates, int, float64, string, error) {
	url := fmt.Sprintf("%s/%s", REST_COUNTRIES_API, strings.ToLower(countryCode)) // Forming the string for the URL
	// Debugging: log.Printf("GET %s", url)
	resp, err := http.Get(url)
	if err != nil {
		return "", structs.PopulatedCoordinates{}, 0, 0, "", err
	}
	defer resp.Body.Close()

	// Checking for HTTP error codes
	if resp.StatusCode != http.StatusOK {
		return "", structs.PopulatedCoordinates{}, 0, 0, "", fmt.Errorf("REST Countries API returned status %d", resp.StatusCode)
	}

	// Read the response body
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", structs.PopulatedCoordinates{}, 0, 0, "", fmt.Errorf("failed to read response body: %v", err)
	}

	// Parse the data into the CountryData struct
	var data []structs.CountryData
	err = json.Unmarshal(body, &data)
	if err != nil || len(data) == 0 {
		return "", structs.PopulatedCoordinates{}, 0, 0, "", fmt.Errorf("failed to parse country data: %v", err)
	}

	country := data[0]
	capital := ""
	if len(country.Capital) > 0 {
		capital = country.Capital[0] // First capital if multiple are available
	}
	area := country.Area
	population := country.Population
	coordinates := structs.Coordinates{}
	if len(country.LatLng) >= 2 {
		coordinates = structs.Coordinates{
			Latitude:  float64(country.LatLng[0]), // These values are should be floats, but API mostly returns ints for the coordinates
			Longitude: float64(country.LatLng[1]),
		}
	} else if len(country.LatLng) < 2 { // Not enough coordinates, trying to avoid panic
		return "", structs.PopulatedCoordinates{}, 0, 0, "", fmt.Errorf("incomplete coordinate data")
	}

	var currencyCode string // The currency code for the country used in getCurrency
	// Iterate over the currencies map to get the first one
	for currencyCode = range country.Currencies {
		break // Exit after getting the first currency
	}

	return capital, structs.PopulatedCoordinates(coordinates), population, area, currencyCode, nil
}

/*
Helper function getWeather API call for the weather using the country coordinates to populate the dashboard with.
Katerina R.
*/
func getWeather(latitude, longitude float64) (float64, float64, error) {
	url := fmt.Sprintf("%slatitude=%f&longitude=%f&hourly=temperature_2m,precipitation", OPEN_METEO_API, latitude, longitude) // Using precipitation, not precipitation_probability
	// Debugging: log.Printf("GET %s", url)
	resp, err := http.Get(url)
	if err != nil {
		return 0, 0, err
	}
	defer resp.Body.Close()

	// Checking for HTTP error codes
	if resp.StatusCode != http.StatusOK {
		return 0, 0, fmt.Errorf("weather API returned status %d", resp.StatusCode)
	}

	// Parsing data
	var data map[string]interface{}
	body, err := io.ReadAll(resp.Body)
	err = json.Unmarshal(body, &data)
	if err != nil {
		return 0, 0, fmt.Errorf("failed to parse weather data")
	}

	hourlyData, ok := data["hourly"].(map[string]interface{})
	if !ok {
		return 0, 0, fmt.Errorf("failed to extract hourly weather data")
	}

	tempuratures := hourlyData["temperature_2m"].([]interface{})  // All the tempuratures values returned from API
	percipitations := hourlyData["precipitation"].([]interface{}) // All the percipitations -''-

	// Calculating mean
	var totalTemp float64
	for _, temp := range tempuratures {
		totalTemp += temp.(float64)
	}
	meanTemp := totalTemp / float64(len(tempuratures))

	var totalPercip float64
	for _, perc := range percipitations {
		totalPercip += perc.(float64)
	}
	meanPercip := totalPercip / float64(len(percipitations))

	return meanTemp, meanPercip, nil
}

/*
Helper function getCurrency API call for the currency using the dashboard configuration to populate the dashboard with.
Katerina R.
*/
func getCurrency(baseCurrency string, currencies []string) (map[string]float64, error) {
	correncyResult := make(map[string]float64)

	url := fmt.Sprintf("%s/%s", CURRENCY_API, baseCurrency)
	// Debugging: log.Printf("GET %s", url)
	resp, err := http.Get(url)
	if err != nil {
		return nil, fmt.Errorf("failed to fetch data for %s: %v", baseCurrency, err)
	}
	defer resp.Body.Close()

	// Checking for HTTP error codes
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("currency API returned status %d for %s", resp.StatusCode, baseCurrency)
	}

	// Parsing data
	var data map[string]interface{}
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to read data for %s: %v", baseCurrency, err)
	}

	err = json.Unmarshal(body, &data)
	if err != nil {
		return nil, fmt.Errorf("failed to parse currency data for %s: %v", baseCurrency, err)
	}

	// Finding rates for the currency
	if rates, ok := data["rates"].(map[string]interface{}); ok {
		for _, currency := range currencies {
			if rate, ok := rates[strings.ToUpper(currency)].(float64); ok {
				correncyResult[currency] = rate
			} else {
				return nil, fmt.Errorf("failed to find rates for %s: %v", currency, err)
			}
		}
	} else {
		return nil, fmt.Errorf("invalid or missing 'rates' data for %s", baseCurrency)
	}
	return correncyResult, nil
}

/*
Helper function getDashboard Returns all the documents and their content from the database back to the user.
Katerina R.
*/
func getDashboard(ctx context.Context, client *firestore.Client, id string) (*structs.DashboardRegistration, error) {
	doc, err := client.Collection(FirestoreCollection).Doc(id).Get(ctx)
	if err != nil {
		return nil, err // dashboard not found-.- be careful what I return here!!
	}

	var dashboard structs.DashboardRegistration
	if err := doc.DataTo(&dashboard); err != nil {
		return nil, err
	}
	return &dashboard, nil
}

/*
RetrieveDashboad function that populates the dashboard according to the configurations.
Katerina R.
*/
func RetrieveDashboad(client *firestore.Client, ctx context.Context) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		log.Printf("Received %s request.", r.Method)

		//Get the parts from the URL path, a different approach than in registration handler
		path := r.URL.Path
		pathParts := strings.Split(path, "/")
		if len(pathParts) < 5 {
			http.Error(w, "Invalid URL", http.StatusBadRequest)
			return
		}

		// Extract the id from right place in the URL path
		id := pathParts[4]
		if id == "" { //
			http.Error(w, "id is required", http.StatusBadRequest)
			return
		}

		// Debugging: log.Printf("Received request for dashboard with ID: %s", id)

		response, err := getDashboard(ctx, client, id)
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}

		dashboard := structs.PopulatedDashboard{
			Country:       response.Country,
			IsoCode:       response.IsoCode,
			Features:      structs.PopulatedFeatures{},
			LastRetrieval: time.Now().Format("20060102 15:04"),
		}

		// Checks for what data to send back to user:

		// Get the country data
		capital, coordinates, population, area, currencyCode, err := getCountryInfo(response.IsoCode)
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}

		if response.Features.Capital {
			dashboard.Features.Capital = &capital
		}

		if response.Features.Coordinates {
			dashboard.Features.Coordinates = &structs.PopulatedCoordinates{
				Latitude:  coordinates.Latitude,
				Longitude: coordinates.Longitude,
			}
		}

		if response.Features.Population {
			dashboard.Features.Population = &population
		}

		if response.Features.Area {
			dashboard.Features.Area = &area
		}

		// Get the weather data
		meanTemp, meanPercip, err := getWeather(coordinates.Latitude, coordinates.Longitude)
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}

		if response.Features.Temperature {
			dashboard.Features.Temperature = &meanTemp
		}

		if response.Features.Precipitation {
			dashboard.Features.Precipitation = &meanPercip
		}

		// Get the currencies data
		currencies, err := getCurrency(currencyCode, response.Features.TargetCurrencies)
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}

		if len(response.Features.TargetCurrencies) > 0 {
			dashboard.Features.TargetCurrencies = &currencies
		}

		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		if err := json.NewEncoder(w).Encode(dashboard); err != nil {
			http.Error(w, "Failed to encode response", http.StatusInternalServerError)
		}
	}
}
