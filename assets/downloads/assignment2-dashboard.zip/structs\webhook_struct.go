package structs

//Written by Sofiya

import (
	_ "cloud.google.com/go/firestore"
	_ "cloud.google.com/go/firestore/apiv1"
	_ "firebase.google.com/go"
	"time"
)

// Webhook struct represents the notification registration
type WebhookRegistration struct {
	ID      string `json:"id" firestore:"id"`
	URL     string `json:"url" firestore:"URL"`
	Country string `json:"country,omitempty" firestore:"Country"` //if Country is an empty string or nil, it will not appear on the JSON output
	Event   string `json:"event" firestore:"Event"`
}

type Webhook struct {
	ID      string `json:"id" firestore:"ID"` //Firestore generated unique ID
	URL     string `json:"url" firestore:"URL"`
	Country string `json:"country,omitempty" firestore:"Country"` //if Country is an empty string or nil, it will not appear on the JSON output
	Event   string `json:"event" firestore:"Event"`
}

type WebhookTrigger struct {
	ID        string    `json:"id" firestore:"ID"` //Firestore generated unique ID
	URL       string    `json:"url" firestore:"URL"`
	Country   string    `json:"country,omitempty" firestore:"Country"` //if Country is an empty string or nil, it will not appear on the JSON output
	Event     string    `json:"event" firestore:"Event"`
	CreatedAt time.Time `json:"createdAt" firestore:"CreatedAt"` // Timestamp for unique ID
}
