package handlers

// Written by: Sofiya
import (
	"Assigment2/structs"
	"cloud.google.com/go/firestore"
	"context"
	"encoding/json"
	"io"
	"log"
	"net/http"
	"strings"
	"time"
)

// HandleDashboardID handles specific dashboard actions (GET, PUT, DELETE)
func HandleNotificationID(client *firestore.Client, ctx context.Context) http.HandlerFunc {
	// Create a new NotificationHandler instance
	notificationHandler := NewNotificationHandler(client)
	// Return a handler function that processes requests for specific dashboard IDs
	return func(w http.ResponseWriter, r *http.Request) {
		// Extract the ID from the URL path and trim the prefix to get the actual ID
		id := strings.TrimPrefix(r.URL.Path, "/dashboard/v1/notifications/")
		if id == "" || strings.Contains(id, "/") {
			http.Error(w, "Invalid request", http.StatusBadRequest)
			return
		}
		// Switch based on the HTTP method to determine the action
		switch r.Method {
		case http.MethodGet:
			notificationHandler.GetWebhookByID(w, r, id)
		case http.MethodPut:
		case http.MethodDelete:
			notificationHandler.DeleteWebhookByID(w, r, id)
		default:
			// If the method is not supported, log the error and return a 405 Method Not Allowed
			log.Println("Unsupported request method " + r.Method)
			http.Error(w, "Unsupported request method "+r.Method, http.StatusMethodNotAllowed)
			return
		}
	}
}

// HandleDashboard handles dashboard actions for creating (POST) and viewing (GET) dashboards
func HandleNotifications(client *firestore.Client, ctx context.Context) http.HandlerFunc {
	// Create a new NotificationHandler instance
	notificationHandler := NewNotificationHandler(client)
	// Return a handler function that processes requests for dashboard actions
	return func(w http.ResponseWriter, r *http.Request) {
		// Switch based on the HTTP method to determine the action
		switch r.Method {
		case http.MethodPost:
			notificationHandler.RegisterWebhook(w, r, client, ctx)
		case http.MethodGet:
			notificationHandler.GetAllWebhooks(w, r)
		default:
			// If the method is not supported, log the error and return a 405 Method Not Allowed
			log.Println("Unsupported request method " + r.Method)
			http.Error(w, "Unsupported request method "+r.Method, http.StatusMethodNotAllowed)
			return
		}
	}
}

// NotificationHandler struct manages the webhook registrations
type NotificationHandler struct {
	Firestore *firestore.Client
}

// NewNotificationHandler initializes a handler with Firestore access
func NewNotificationHandler(fs *firestore.Client) *NotificationHandler {
	return &NotificationHandler{Firestore: fs}
}

// RegisterWebhook handles webhook registration (POST /dashboard/v1/notifications/)
func (h *NotificationHandler) RegisterWebhook(w http.ResponseWriter, r *http.Request, client *firestore.Client, ctx context.Context) {
	// Checking if the request method is POST, since only POST requests are allowed for webhook registration
	if r.Method != http.MethodPost {
		http.Error(w, "Method Not Allowed", http.StatusMethodNotAllowed)
		return
	}

	// Reading the body of the request and unmarshalling it into a WebhookRegistration struct
	content, err := io.ReadAll(r.Body)
	webhook := structs.WebhookRegistration{}
	err = json.Unmarshal(content, &webhook)
	// If there is an error in unmarshalling, log the error and return a 400 Bad Request
	if err != nil {
		log.Printf("Error unmarshalling body from POST request: %v", err)
		http.Error(w, "Invalid JSON", http.StatusBadRequest)
		return
	}
	// If the request body is empty, return a 400 Bad Request
	id := client.Collection(FirestoreNotifications).NewDoc()
	webhook.ID = id.ID
	_, err = id.Set(ctx, webhook)
	// If there is an error in adding the document to Firestore, log the error and return a 500 Internal Server Error
	if err != nil {
		log.Printf("Error adding dashboard: %v", err)
		http.Error(w, "Error adding dashboard", http.StatusInternalServerError)
		return
	}

	// Validate that required fields are not empty (event and url)
	if webhook.URL == "" || webhook.Event == "" {
		//If the request is invalid, return an error message
		http.Error(w, "Missing required fields: url and event", http.StatusBadRequest)
		return
	}

	log.Println("Webhook added successfully!")
	//http.Error(w, id.ID, http.StatusOK)
	json.NewEncoder(w).Encode(map[string]string{"id": webhook.ID})

}

// GetWebhookByID handles retrieving a specific webhook by its ID (GET /dashboard/v1/notifications/{id})
func (h *NotificationHandler) GetWebhookByID(w http.ResponseWriter, r *http.Request, id string) {
	// Only allow GET requests
	if r.Method != http.MethodGet {
		http.Error(w, "Method Not Allowed", http.StatusMethodNotAllowed)
		return
	}

	// Attempting to retrieve the document from Firestore by ID
	doc, err := h.Firestore.Collection("webhooks").Doc(id).Get(r.Context())
	if err != nil {
		http.Error(w, "Webhook not found", http.StatusNotFound)
		return
	}

	// Converting the Firestore document into a Webhook struct
	var webhook structs.Webhook
	err = doc.DataTo(&webhook)
	if err != nil {
		http.Error(w, "Failed to parse webhook data", http.StatusInternalServerError)
		return
	}

	// Return the webhook as JSON
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(webhook)
}

// DeleteWebhookByID handles deleting a specific webhook (DELETE /dashboard/v1/notifications/{id})
func (h *NotificationHandler) DeleteWebhookByID(w http.ResponseWriter, r *http.Request, id string) {
	// Only allow DELETE requests
	if r.Method != http.MethodDelete {
		http.Error(w, "Method Not Allowed", http.StatusMethodNotAllowed)
		return
	}

	// Check if the webhook with given ID exists in Firestore
	_, err := h.Firestore.Collection("webhooks").Doc(id).Get(r.Context())
	if err != nil {
		// If it doesn't exist, respond with 404
		http.Error(w, "Webhook not found", http.StatusNotFound)
		return
	}

	// Attempt to delete the webhook document from Firestore
	if _, err := h.Firestore.Collection("webhooks").Doc(id).Delete(r.Context()); err != nil {
		http.Error(w, "Failed to delete webhook", http.StatusInternalServerError)
		return
	}

	// Respond with confirmation that deletion was successful
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{"message": "Webhook deleted successfully"})
}

// GetAllWebhooks handles listing all registered webhooks (GET /dashboard/v1/notifications/)
func (h *NotificationHandler) GetAllWebhooks(w http.ResponseWriter, r *http.Request) {
	// Only allow GET requests
	if r.Method != http.MethodGet {
		http.Error(w, "Method Not Allowed", http.StatusMethodNotAllowed)
		return
	}

	// Attempt to fetch all documents from the "webhooks" collection in Firestore
	docs, err := h.Firestore.Collection("webhooks").Documents(r.Context()).GetAll()
	if err != nil {
		// If there's an error retrieving data, return a 500 Internal Server Error
		http.Error(w, "Failed to retrieve webhooks", http.StatusInternalServerError)
		return
	}

	// Slice to store all decoded webhook entries
	var webhooks []structs.Webhook

	// Loop through each Firestore document
	for _, doc := range docs {
		var webhook structs.Webhook

		// Try to convert Firestore document data into a Webhook struct
		if err := doc.DataTo(&webhook); err == nil {
			// If successful, append the webhook to our slice
			webhooks = append(webhooks, webhook)
		}
	}

	// Set the Content-Type header so the client knows we're returning JSON
	w.Header().Set("Content-Type", "application/json")

	// Encode the slice of webhooks as a JSON response
	json.NewEncoder(w).Encode(webhooks)
}

// TriggerWebhooks finds and notifies all matching webhooks for a specific event and country.
// It sends a POST request with event details to each matching webhook URL.
func (h *NotificationHandler) TriggerWebhooks(event, country string) {
	// Retrieve all webhook documents from Firestore
	docs, err := h.Firestore.Collection(FirestoreNotifications).Documents(context.Background()).GetAll()
	if err != nil {
		// If retrieval fails, just log and return (don't break the service)
		return
	}

	// Loop through all webhook documents
	for _, doc := range docs {
		var webhook structs.WebhookTrigger
		if err := doc.DataTo(&webhook); err != nil {
			// Skip any document we fail to parse
			continue
		}

		// Check if the webhook is registered for the given event
		if webhook.Event != event {
			continue
		}

		// If the webhook has a country filter, it must match the given country
		if webhook.Country != "" && webhook.Country != country {
			continue
		}

		// Prepare JSON payload to send to the webhook
		payload := map[string]string{
			"id":      webhook.ID,
			"country": country,
			"event":   event,
			"time":    time.Now().Format("20060102 15:04"), // time at which the event occurred
		}
		jsonBody, _ := json.Marshal(payload)

		// Send POST request to the webhook URL (in a goroutine)
		go http.Post(webhook.URL, "application/json", strings.NewReader(string(jsonBody)))
	}
}
