package structs

//Written by Katerina R.

import (
	_ "cloud.google.com/go/firestore"
	firestore "cloud.google.com/go/firestore/apiv1"
	_ "firebase.google.com/go"
)

// DashboardHandler struct to hold Firestore client
type DashboardHandler struct {
	client *firestore.Client
}

// Struct for dashboard registration
// Katerina R. & Katharina K.
type DashboardRegistration struct {
	ID         string   `json:"id" firestore:"id"`
	Country    string   `json:"country" firestore:"country"`
	IsoCode    string   `json:"isoCode" firestore:"isoCode"`
	Features   Features `json:"features" firestore:"features"`
	LastChange string   `json:"lastChange" firestore:"lastChange"`
}

// Dashboard features
// Katerina R. & Katharina K.
type Features struct {
	Temperature      bool     `json:"temperature" firestore:"temperature"`
	Precipitation    bool     `json:"precipitation" firestore:"precipitation"`
	Capital          bool     `json:"capital" firestore:"capital"`
	Coordinates      bool     `json:"coordinates" firestore:"coordinates"`
	Population       bool     `json:"population" firestore:"population"`
	Area             bool     `json:"area" firestore:"area"`
	TargetCurrencies []string `json:"targetCurrencies" firestore:"targetCurrencies"`
}

// Struct for the populated dashboards
// Katerina R.
type PopulatedDashboard struct {
	Country       string            `json:"country"`
	IsoCode       string            `json:"isoCode"`
	Features      PopulatedFeatures `json:"features"`
	LastRetrieval string            `json:"lastRetrieval"`
}

// Populated dashboard features (for API calls). These do not need the firestore name because they will never be stored there
// Katerina R.
type PopulatedFeatures struct {
	Temperature      *float64              `json:"temperature"` // Reference because this way we can indicate that the value is not set, and not just returning 0.0!!
	Precipitation    *float64              `json:"precipitation"`
	Capital          *string               `json:"capital"`
	Coordinates      *PopulatedCoordinates `json:"coordinates"`
	Population       *int                  `json:"population"`
	Area             *float64              `json:"area"`
	TargetCurrencies *map[string]float64   `json:"targetCurrencies"`
}

// Struct for the coordinates for the populated features
// Katerina R.
type PopulatedCoordinates struct {
	Latitude  float64 `json:"latitude"`
	Longitude float64 `json:"longitude"`
}
