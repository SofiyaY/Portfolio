package main

import (
	"Assigment2/handlers"
	"cloud.google.com/go/firestore"
	"context"
	_ "encoding/json"
	_ "errors"
	firebase "firebase.google.com/go"
	_ "firebase.google.com/go/auth"
	"google.golang.org/api/option"
	_ "io"
	"log"
	"net/http"
	"os"
	_ "time"
)

// Firebase context and client used by Firestore functions throughout the program.
var ctx context.Context
var client *firestore.Client

func main() {

	// Firebase initialisation
	ctx = context.Background()

	opt := option.WithCredentialsFile("./assignment-2-ddecb-firebase-adminsdk-fbsvc-a5351324e0.json")
	app, err := firebase.NewApp(ctx, nil, opt)
	if err != nil {
		log.Printf("error initializing app: %v", err)
		return
	}

	// Instantiate client
	client, err = app.Firestore(ctx)
	if ctx == nil {
		log.Fatal("context is nil")
	}

	// Check whether there is an error when connecting to Firestore
	if err != nil {
		log.Printf("Error initializing firestore: %v", err)
		return
	}

	defer client.Close()

	log.Println("Firestore client initialized successfully!")

	PORT := "8080"

	if os.Getenv("PORT") != "" {
		PORT = os.Getenv("PORT")
	}

	if PORT == "" {
		log.Println("$PORT has not been set. Default: 8080")
		PORT = "8080"
	}

	router := http.NewServeMux()

	router.HandleFunc("/", handlers.HomepageHandler)
	router.HandleFunc("/dashboard/v1/registrations/", handlers.HandleDashboard(client, ctx))
	router.HandleFunc("/dashboard/v1/registrations/{id}", handlers.HandleDashboardID(client, ctx))
	router.HandleFunc("/dashboard/v1/dashboards/{id}", handlers.RetrieveDashboad(client, ctx))
	router.HandleFunc("/dashboard/v1/notifications/", handlers.HandleNotifications(client, ctx))
	router.HandleFunc("/dashboard/v1/notifications/{id}", handlers.HandleNotificationID(client, ctx))
	router.Handle("/dashboard/v1/status/", handlers.NewStatushandler(client))

	log.Fatal(http.ListenAndServe(":"+PORT, router))
}
