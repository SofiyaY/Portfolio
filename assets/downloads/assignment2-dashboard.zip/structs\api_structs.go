package structs

//Written by Katerina R.

// CountryAPI Struct for CountryAPI data
type CountryAPI []CountryData

// CountryData Struct for the country data from the API
type CountryData struct {
	Name       CountryName         `json:"name"`
	Capital    []string            `json:"capital"`
	Population int                 `json:"population"`
	Area       float64             `json:"area"`
	LatLng     []float64           `json:"latlng"`
	Currencies map[string]Currency `json:"currencies"`
}

// CountryName Struct for the country name in the country data from API
type CountryName struct {
	Common   string `json:"common"`
	Official string `json:"official"`
}

// Currency Struct for country currency in the country data from API
type Currency struct {
	Name   string `json:"name"`
	Symbol string `json:"symbol"`
}

// Coordinates Struct for the coordinates for the country
type Coordinates struct {
	Latitude  float64 `json:"latitude"`
	Longitude float64 `json:"longitude"`
}
