package status

//Written by Katharina

import "time"

// UptimeSeconds returns the number of seconds since the program started
var startTime = time.Now()

// UptimeSeconds returns the number of seconds since the program started
func UptimeSeconds() int64 {
	return int64(time.Since(startTime).Seconds())

}
