package testing_Handler

// Implemented by Sofiya

import (
	"Assigment2/handlers"
	"Assigment2/structs"
	"cloud.google.com/go/firestore"
	"context"
	"encoding/json"
	"github.com/stretchr/testify/assert"
	"google.golang.org/api/option"
	"net/http"
	"net/http/httptest"
	"testing"
)

// setupFirestoreStatus sets up a Firestore client for testing purposes
func setupFirestoreStatus(t *testing.T) *firestore.Client {
	ctx := context.Background()
	opt := option.WithCredentialsFile("assignment-2-11fae-firebase-adminsdk-fbsvc-a10f5f10dd.json")
	client, err := firestore.NewClient(ctx, "assignment-2-11fae", opt)
	if err != nil {
		t.Fatalf("Failed to create Firestore client: %v", err)
	}
	return client
}

// TestStatusHandler_GET tests the GET method of the StatusHandler to ensure it returns
// the correct status response.
func TestStatusHandler_GET(t *testing.T) {
	client := setupFirestoreStatus(t)
	defer client.Close()

	// Create a new StatusHandler instance
	handler := handlers.NewStatushandler(client)

	// Create a new HTTP request for the status endpoint
	req := httptest.NewRequest(http.MethodGet, "/dashboard/v1/status", nil)
	rec := httptest.NewRecorder()

	// Call the ServeHTTP method of the StatusHandler with the request and response recorder
	handler.ServeHTTP(rec, req)

	// Check the response status code
	assert.Equal(t, http.StatusOK, rec.Code)

	// Check the response body
	var resp structs.StatusResponse
	// Decode the JSON response into the StatusResponse struct
	err := json.NewDecoder(rec.Body).Decode(&resp)

	// Assert that there are no errors during decoding
	assert.NoError(t, err)
	// Assert that the response contains the expected fields
	assert.Equal(t, "v1", resp.Version)
	// Asserts that the status are 200 or 500 if the firestore is not reachable
	assert.Contains(t, []int{200, 500}, int(resp.NotificationDB))
	// Assert that the webhooks count is greater than or equal to 0
	assert.GreaterOrEqual(t, resp.Webhooks, 0)
}
