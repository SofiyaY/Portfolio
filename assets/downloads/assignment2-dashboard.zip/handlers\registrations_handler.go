package handlers

// Written by: Katerina R. and Katharina
// TriggerWebhook method added/implementing by Sofiya

import (
	"Assigment2/structs"
	"cloud.google.com/go/firestore"
	"context"
	"encoding/json"
	_ "errors"
	_ "fmt"
	"google.golang.org/api/iterator"
	_ "google.golang.org/api/iterator"
	"io"
	"log"
	"net/http"
	"strings"
	"time"
	_ "time"
)

/*
HandleDashboardID handler for all dashboard-related operations (GET, PUT, DELETE) using ID
*/
func HandleDashboardID(client *firestore.Client, ctx context.Context) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		id := strings.TrimPrefix(r.URL.Path, "/dashboard/v1/registrations/")

		if id == "" || strings.Contains(id, "/") {
			http.Error(w, "Invalid request", http.StatusBadRequest)
			return
		}
		switch r.Method {
		case http.MethodGet:
			ViewDashboard(w, r, client, ctx, id)
		case http.MethodPut:
			replaceDashboard(w, r, client, ctx, id)
		case http.MethodDelete:
			deleteDashboard(w, r, client, ctx, id)
		default:
			log.Println("Unsupported request method " + r.Method)
			http.Error(w, "Unsupported request method "+r.Method, http.StatusMethodNotAllowed)
			return
		}
	}
}

/*
HandleDashboardID handler for all dashboard-related operations (POST, GET) without ID
Katerina R.
*/
func HandleDashboard(client *firestore.Client, ctx context.Context) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		switch r.Method {
		case http.MethodPost:
			addDashboard(w, r, client, ctx)
		case http.MethodGet:
			viewDashboards(w, r, client, ctx)
		default:
			log.Println("Unsupported request method " + r.Method)
			http.Error(w, "Unsupported request method "+r.Method, http.StatusMethodNotAllowed)
			return
		}
	}
}

/*
addDashboard Reads a string from the body in plain-text and sends it to Firestore to be registered as a dashboard. Triggers are implemented accordingly.
Katerina R.
*/
func addDashboard(w http.ResponseWriter, r *http.Request, client *firestore.Client, ctx context.Context) {
	log.Printf("Received %s request.", r.Method)

	// Reading the body
	content, err := io.ReadAll(r.Body)
	if err != nil {
		log.Printf("Error reading body from POST request: %v", err)
		http.Error(w, "Error reading body from POST request", http.StatusBadRequest)
		return
	}

	// Checking the body from the POST request
	if len(content) == 0 {
		log.Printf("Empty body")
		http.Error(w, "Request body is empty", http.StatusBadRequest)
		return
	} else {
		// Try to parse the JSON body into a DashboardRegistration struct
		dashboard := structs.DashboardRegistration{}
		err = json.Unmarshal(content, &dashboard)
		if err != nil {
			log.Printf("Error unmarshalling body from POST request: %v", err)
			http.Error(w, "Invalid JSON", http.StatusBadRequest)
			return
		}

		// Creating the document
		id := client.Collection(FirestoreCollection).NewDoc() // This way I can add the ID to the dashboard as well as to the collection
		dashboard.ID = id.ID                                  // Saving the generated ID in the struct
		dashboard.LastChange = time.Now().Format("20060102 15:04")

		// Writing the dashboard to the database
		_, err = id.Set(ctx, dashboard)
		if err != nil {
			log.Printf("Error adding dashboard: %v", err)
			http.Error(w, "Error adding dashboard", http.StatusInternalServerError)
			return
		}

		log.Printf("Dashboard added successfully!")
		//  Trigger webhook with event "REGISTER"
		notificationHandler := NewNotificationHandler(client)
		isoForNotif := strings.ToUpper(dashboard.IsoCode)
		go notificationHandler.TriggerWebhooks("REGISTER", isoForNotif)

		// Return ID and LastChange to client
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]string{"id": id.ID, "lastChange": dashboard.LastChange})
	}
}

/*
viewDashboards Returns all the documents and their content from the database back to the user. Triggers are implemented accordingly.
Katerina R.
*/
func viewDashboards(w http.ResponseWriter, r *http.Request, client *firestore.Client, ctx context.Context) {
	log.Printf("Received %s request.", r.Method)

	// Query all documents from the collection
	documents := client.Collection(FirestoreCollection).Documents(ctx)

	var dashboards []struct {
		ID         string           `json:"id"`
		Country    string           `json:"country"`
		IsoCode    string           `json:"isoCode"`
		Features   structs.Features `json:"features"`
		LastChange string           `json:"lastChange"`
	}

	// Iterating thought documents
	for {
		doc, err := documents.Next()
		if err != nil {
			if err == iterator.Done { // No document
				log.Printf("No dashboards found.")
				w.Header().Set("Content-Type", "application/json")
				w.WriteHeader(http.StatusOK)
				json.NewEncoder(w).Encode([]any{})
				break
			}
			// Unexpected error while iterating
			log.Printf("Error iterating dashboards: %v", err)
			http.Error(w, "Error iterating dashboards", http.StatusInternalServerError)
			return
		}
		// Deserialize Firestore document into DashboardRegistration
		var dashboard structs.DashboardRegistration
		if err := doc.DataTo(&dashboard); err != nil {
			log.Printf("Error converting dashboard to struct: %v", err)
			http.Error(w, "Error converting dashboard to struct", http.StatusInternalServerError)
			return
		}

		// Append the dashboard data to the response list
		dashboards = append(dashboards, struct {
			ID         string           `json:"id"`
			Country    string           `json:"country"`
			IsoCode    string           `json:"isoCode"`
			Features   structs.Features `json:"features"`
			LastChange string           `json:"lastChange"`
		}{
			ID:         doc.Ref.ID,
			Country:    dashboard.Country,
			IsoCode:    dashboard.IsoCode,
			Features:   dashboard.Features,
			LastChange: dashboard.LastChange,
		})

		// Trigger webhook for event INVOKE
		notificationHandler := NewNotificationHandler(client)
		isoForNotif := strings.ToUpper(dashboard.IsoCode)
		go notificationHandler.TriggerWebhooks("INVOKE", isoForNotif)
	}

	// Return the list of dashboards as JSON
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	if err := json.NewEncoder(w).Encode(dashboards); err != nil {
		log.Printf("Error encoding dashboards: %v", err)
		http.Error(w, "Error encoding dashboards", http.StatusInternalServerError)
	}
}

/*
Lists a specific documents in the collection to the user. Reqeuested after a specific ID.
Katharina
*/
func ViewDashboard(w http.ResponseWriter, r *http.Request, client *firestore.Client,
	ctx context.Context, dashboardId string) {

	log.Println("Received "+r.Method+" request. Dashboard:", dashboardId)

	//validate the dashboardId
	if dashboardId == "" {
		http.Error(w, "Missing dashboard ID", http.StatusBadRequest)
		return
	}

	//retrieve the document from Firestore, specifying dashboardId
	doc, err := client.Collection(FirestoreCollection).Doc(dashboardId).Get(ctx)
	if err != nil {
		log.Println("Dashboard not found", err)
		http.Error(w, "Dashboard not found", http.StatusNotFound)
		return
	}

	//deserialize the document into a DashboardRegistration struct
	var dashboard structs.DashboardRegistration
	if err := doc.DataTo(&dashboard); err != nil {
		log.Println("Error decoding Firestore document:", err)
		http.Error(w, "Error decoding dashboard data", http.StatusInternalServerError)
		return
	}

	//will insure that the document has a reference ID that is valid
	if doc.Ref.ID == "" {
		log.Println("Dashboard has no reference ID in Firestore Document")
		http.Error(w, "Dashboard has no reference ID in Firestore Document", http.StatusBadRequest)
		return
	}
	dashboard.ID = doc.Ref.ID

	//failback if the lastChange field is empty
	if dashboard.LastChange == "" {
		dashboard.LastChange = "unknown"
	}

	//send the dashboard data back to the user in JSON format
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	if err := json.NewEncoder(w).Encode(dashboard); err != nil {
		log.Println("Error encoding dashboard: %v", err)
		http.Error(w, "Error encoding dashboard", http.StatusInternalServerError)
		return
	}
	// Trigger webhook for event INVOKE
	notificationHandler := NewNotificationHandler(client)
	notifISO := strings.ToUpper(dashboard.IsoCode)
	go notificationHandler.TriggerWebhooks("INVOKE", notifISO)

}

/*
deleteDashboard deletes a dashboard from the Firestore database. this is based on a provided ID. it will return
a 204 status code if successful, or an error message if not. This also triggers a webhook for DELETE.
Katharina
*/
func deleteDashboard(w http.ResponseWriter, r *http.Request,
	client *firestore.Client, ctx context.Context, dashboardId string) {

	log.Println("Received " + r.Method + " request to delete dashboard: " + dashboardId)

	//validate that the dashboardId is not empty
	if dashboardId == "" {
		http.Error(w, "Missing dashboard ID", http.StatusBadRequest)
		return
		//
	}

	//reference for the document to be deleted
	docRef := client.Collection(FirestoreCollection).Doc(dashboardId)

	//Check if the document exists
	doc, err := docRef.Get(ctx)
	if err != nil {
		log.Println("Dashboard not found", err)
		http.Error(w, "Dashboard not found", http.StatusNotFound)
		return
	}

	//Webhook
	//decode the document into a DashboardRegistration struct to extract the webhook
	var dashboard structs.DashboardRegistration
	if err := doc.DataTo(&dashboard); err != nil {
		log.Println("Error decoding Firestore document:", err)
		http.Error(w, "Error decoding dashboard data", http.StatusInternalServerError)
		return
	}

	//delete the document from Firestore
	_, err = docRef.Delete(ctx)
	if err != nil {
		log.Println("Failed to delete dashboard:", err)
		http.Error(w, "Failed to delete dashboard", http.StatusInternalServerError)
		return
	}

	//send a 204 No Content response on successfull deletion
	w.WriteHeader(http.StatusNoContent)
	// Trigger webhook for DELETE, asynchronous
	notificationHandler := NewNotificationHandler(client)
	notifISO := strings.ToUpper(dashboard.IsoCode)
	go notificationHandler.TriggerWebhooks("DELETE", notifISO)

}

/*
replaceDashboard replaces the content (or updates) of a dashboard in the Firestore database. it decodes a new dashboard
config from the request body and saves it to the database. it updates timestamp of lastchange
and triggers a webhook for CHANGE.
Katharina
*/
func replaceDashboard(w http.ResponseWriter, r *http.Request, client *firestore.Client,
	ctx context.Context, dashboardId string) {

	log.Println("Received " + r.Method + " request on ID:" + dashboardId)

	//validate that the dashboardId is not empty
	if dashboardId == "" {
		http.Error(w, "Missing dashboard ID", http.StatusBadRequest)
	}

	//decode new dashboard config from request body
	var update structs.DashboardRegistration
	if err := json.NewDecoder(r.Body).Decode(&update); err != nil {
		log.Println("Invalid JSON body", err)
		http.Error(w, "Invalid JSON body", http.StatusBadRequest)
		return
	}

	//override, or set the ID of the dashboard to be updated
	update.ID = dashboardId

	//update lastchange, with format YYYYMMDD HH:MM
	update.LastChange = time.Now().Format("20060102 15:04")

	//save/replace/override the document in firestore
	_, err := client.Collection(FirestoreCollection).Doc(dashboardId).Set(ctx, update)
	if err != nil {
		log.Println("Failed to update dashboard:", err)
		http.Error(w, "Failed to update dashboard", http.StatusInternalServerError)
		return
	}

	//send a 204 No Content response on successful update
	w.WriteHeader(http.StatusNoContent)
	// Trigger webhook for REPLACE/CHANGE
	notificationHandler := NewNotificationHandler(client)
	notifISO := strings.ToUpper(update.IsoCode)
	go notificationHandler.TriggerWebhooks("CHANGE", notifISO)

}
