package handlers

//Written by: Katharina

import (
	"Assigment2/status"
	"Assigment2/structs"
	"cloud.google.com/go/firestore"
	"encoding/json"
	"net/http"
)

// This handles the status of the APIs and the database
type StatusHandler struct {
	Firestore *firestore.Client // Firestore client to interact with the database
}

// NewStatushandler creates a new StatusHandler instance
func NewStatushandler(fs *firestore.Client) *StatusHandler {
	return &StatusHandler{fs}
}

// ServeHTTP handles the HTTP requests for the status endpoint
func (h *StatusHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	//this only allowes GET requests
	if r.Method != http.MethodGet {
		http.Error(w, "Method Not Allowed", http.StatusMethodNotAllowed)
		return
	}

	ctx := r.Context()

	//checks if the APIs are reachable
	countriesAPI := status.PingURL("http://129.241.150.113:8080/v3.1/all")
	meteoAPI := status.PingURL("https://api.open-meteo.com/v1/forecast?latitude=0&longitude=0&hourly=temperature_2m")
	currencyAPI := status.PingURL("http://129.241.150.113:9090/currency/NOK")

	//initializes notification database status
	webhooks := 0
	notifStatus := 500

	//attempts to get all documents from the Firestore collection
	docs, err := h.Firestore.Collection(FirestoreNotifications).Documents(ctx).GetAll()
	if err != nil {
		notifStatus = 500 // If there is an error, set the status to 500, firestore is not reachable :p
	} else {
		// If successful, set the status to 200 and count the number of documents, representing the number of webhooks
		webhooks = len(docs)
		notifStatus = 200
	}

	//builds the response struct
	resp := structs.StatusResponse{
		CountriesAPI:   countriesAPI,
		MeteoAPI:       meteoAPI,
		CurrencyAPI:    currencyAPI,
		NotificationDB: notifStatus,
		Webhooks:       webhooks,
		Version:        "v1",
		Uptime:         status.UptimeSeconds(),
	}

	//responds with the status in JSON format:)
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(resp)

}
