package testing_Handler

//Implemented by Sofiya
import (
	"Assigment2/handlers"
	"cloud.google.com/go/firestore"
	"golang.org/x/net/context"
	"google.golang.org/api/option"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
)

// setupFirestoreStubforNotification sets up a Firestore client for testing purposes
// and returns the client and context.
func setupFirestoreStubforNotification(t *testing.T) (*firestore.Client, context.Context) {
	ctx := context.Background()
	opt := option.WithCredentialsFile("assignment-2-11fae-firebase-adminsdk-fbsvc-a10f5f10dd.json")
	client, err := firestore.NewClient(ctx, "assignment-2-11fae", opt)
	if err != nil {
		t.Fatalf("Failed to create Firestore client: %v", err)
	}
	return client, ctx
}

// TestRegisterWebhook_InvalidPayload tests the RegisterWebhook method with an invalid payload
// to ensure it returns a 400 Bad Request status.
func TestRegisterWebhook_InvalidPayload(t *testing.T) {
	// Set up the Firestore client
	client, ctx := setupFirestoreStubforNotification(t)
	// Defer closing the client to ensure resources are cleaned up
	defer client.Close()
	// Create a new NotificationHandler instance
	handler := handlers.NewNotificationHandler(client)
	// Create a new HTTP request with an invalid payload (not valid JSON)
	// and a response recorder to capture the response
	request := httptest.NewRequest(http.MethodPost, "/dashboard/v1/notifications/", strings.NewReader("invalid json"))
	response := httptest.NewRecorder()
	// Call the RegisterWebhook method with the request and response recorder
	handler.RegisterWebhook(response, request, client, ctx)
	// Assert that the response status code is 400 Bad Request
	assert.Equal(t, http.StatusBadRequest, response.Result().StatusCode)
}

// TestGetWebhookByID_InvalidMethod tests the GetWebhookByID method with an invalid HTTP method
func TestGetWebhookByID_InvalidMethod(t *testing.T) {
	// Set up the Firestore client
	client, _ := setupFirestoreStubforNotification(t)
	// Defer closing the client to ensure resources are cleaned up
	defer client.Close()
	// Create a new NotificationHandler instance
	handler := handlers.NewNotificationHandler(client)
	// Create a new HTTP request with an invalid method (not GET)
	request := httptest.NewRequest(http.MethodPost, "/dashboard/v1/notifications/id123", nil)
	response := httptest.NewRecorder()
	// Call the GetWebhookByID method with the request and response recorder
	// and a dummy ID ("id123") and assert that the response status code is 405 Method Not Allowed
	handler.GetWebhookByID(response, request, "id123")
	assert.Equal(t, http.StatusMethodNotAllowed, response.Result().StatusCode)
}

// TestDeleteWebhookByID_InvalidMethod tests the DeleteWebhookByID method with an invalid HTTP method
func TestDeleteWebhookByID_InvalidMethod(t *testing.T) {
	// Set up the Firestore client
	client, _ := setupFirestoreStubforNotification(t)
	defer client.Close()
	// Create a new NotificationHandler instance
	handler := handlers.NewNotificationHandler(client)
	// Create a new HTTP request with an invalid method (not DELETE)
	request := httptest.NewRequest(http.MethodGet, "/dashboard/v1/notifications/id123", nil)
	response := httptest.NewRecorder()
	// Call the DeleteWebhookByID method with the request and response recorder
	handler.DeleteWebhookByID(response, request, "id123")
	// Assert that the response status code is 405 Method Not Allowed
	assert.Equal(t, http.StatusMethodNotAllowed, response.Result().StatusCode)
}

// TestGetAllWebhooks_InvalidMethod tests the GetAllWebhooks method with an invalid HTTP method
// to ensure it returns a 405 Method Not Allowed status.
func TestGetAllWebhooks_InvalidMethod(t *testing.T) {
	// Set up the Firestore client
	client, _ := setupFirestoreStubforNotification(t)
	defer client.Close()
	// Create a new NotificationHandler instance
	handler := handlers.NewNotificationHandler(client)
	// Create a new HTTP request with an invalid method (not GET)
	request := httptest.NewRequest(http.MethodPost, "/dashboard/v1/notifications/", nil)
	response := httptest.NewRecorder()
	// Call the GetAllWebhooks method with the request and response recorder
	handler.GetAllWebhooks(response, request)
	// Assert that the response status code is 405 Method Not Allowed
	assert.Equal(t, http.StatusMethodNotAllowed, response.Result().StatusCode)
}

// TestTriggerWebhooks tests the TriggerWebhooks method to ensure it executes without panic or error.
func TestTriggerWebhooks(t *testing.T) {
	// Set up the Firestore client
	client, _ := setupFirestoreStubforNotification(t)
	defer client.Close()
	// Create a new NotificationHandler instance
	handler := handlers.NewNotificationHandler(client)
	// Call the TriggerWebhooks method with a dummy event type and ID
	go handler.TriggerWebhooks("REGISTER", "NO")
	// Wait for a second to allow the goroutine to execute
	time.Sleep(1 * time.Second) //
	// Assert that the method executed without panic or error
	assert.True(t, true, "TriggerWebhooks executed without panic")
}
