package testing_Handler

//Implemented by Sofiya, struggeled by katharina
import (
	"Assigment2/handlers"
	"cloud.google.com/go/firestore"
	"context"
	"github.com/stretchr/testify/assert"
	"google.golang.org/api/option"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

// setupFirestoreRegistration sets up a Firestore client for testing purposes
func setupFirestoreRegistration(t *testing.T) (*firestore.Client, context.Context) {
	ctx := context.Background()
	opt := option.WithCredentialsFile("assignment-2-11fae-firebase-adminsdk-fbsvc-a10f5f10dd.json")
	client, err := firestore.NewClient(ctx, "assignment-2-11fae", opt)
	if err != nil {
		t.Fatalf("Failed to create Firestore client: %v", err)
	}
	return client, ctx
}

// TestAddDashboard_ValidPayload tests the AddDashboard method to ensure it correctly adds a dashboard
func TestAddDashboard_InvalidJSON(t *testing.T) {
	// Set up the Firestore client
	client, ctx := setupFirestoreRegistration(t)
	defer client.Close()
	// Create a new DashboardHandler instance
	handler := handlers.HandleDashboard(client, ctx)
	// Create a new HTTP request with an invalid payload (not valid JSON)
	req := httptest.NewRequest(http.MethodPost, "/dashboard/v1/registrations", strings.NewReader("invalid json"))
	rec := httptest.NewRecorder()
	// Call the ServeHTTP method of the DashboardHandler with the request and response recorder
	handler.ServeHTTP(rec, req)
	assert.Equal(t, http.StatusBadRequest, rec.Code)
}

// TestGetDashboardByID_InvalidMethod tests the GetDashboardByID method with an invalid HTTP method
func TestViewDashboard_InvalidID(t *testing.T) {
	// Set up the Firestore client
	client, ctx := setupFirestoreRegistration(t)
	defer client.Close()
	// Create a new DashboardHandler instance
	handler := handlers.HandleDashboardID(client, ctx)
	// Create a new HTTP request with an invalid method (not GET)
	req := httptest.NewRequest(http.MethodGet, "/dashboard/v1/registrations/", nil)
	rec := httptest.NewRecorder()
	// Call the ServeHTTP method of the DashboardHandler with the request and response recorder
	handler.ServeHTTP(rec, req)
	assert.Equal(t, http.StatusBadRequest, rec.Code)
}

// TestGetDashboardByID_InvalidMethod tests the GetDashboardByID method with an invalid HTTP method
func TestUnsupportedMethod(t *testing.T) {
	client, ctx := setupFirestoreRegistration(t)
	defer client.Close()
	// Create a new DashboardHandler instance
	handler := handlers.HandleDashboard(client, ctx)
	// Create a new HTTP request with an unsupported method (PUT)
	req := httptest.NewRequest(http.MethodPut, "/dashboard/v1/registrations", nil)
	rec := httptest.NewRecorder()
	// Call the ServeHTTP method of the DashboardHandler with the request and response recorder
	handler.ServeHTTP(rec, req)
	assert.Equal(t, http.StatusMethodNotAllowed, rec.Code)
}
