package models

// Country represents information about a country
type Country struct {
	Name       string `json:"name"`
	Capital    string `json:"capital"`
	Region     string `json:"region"`
	Subregion  string `json:"subregion"`
	Population int    `json:"population"`
}

// RestCountry represents the partial structure returned by REST Countries API.
type RestCountry struct {
	Name struct {
		Common string `json:"common"`
	} `json:"name"`
	Continents []string          `json:"continents"`
	Population int               `json:"population"`
	Languages  map[string]string `json:"languages"`
	Borders    []string          `json:"borders"`
	Capital    []string          `json:"capital"`
	Flags      map[string]string `json:"flags"`
}

// CountryInfoResponse is the final output structure for the /info endpoint.
type CountryInfoResponse struct {
	Name       string            `json:"name"`
	Continents []string          `json:"continents"`
	Population int               `json:"population"`
	Languages  map[string]string `json:"languages"`
	Borders    []string          `json:"borders"`
	Flag       string            `json:"flag"`
	Capital    string            `json:"capital"`
	Cities     []string          `json:"cities"`
}
