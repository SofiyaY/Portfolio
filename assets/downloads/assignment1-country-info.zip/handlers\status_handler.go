package handlers

import (
	"encoding/json"
	"net/http"
	"time"
)

// StartTime holds the time when the service was started.
var StartTime time.Time

// SetStartTime initializes the global start time.
func SetStartTime(t time.Time) {
	StartTime = t
}

// StatusHandler returns a status overview of the dependent services and the uptime.
func StatusHandler(w http.ResponseWriter, r *http.Request) {
	// Static Values
	restCountriesStatus := "200 OK"
	countriesNowStatus := "200 OK"
	uptime := int(time.Since(StartTime).Seconds())

	status := map[string]interface{}{
		"countriesnowapi":  countriesNowStatus,
		"restcountriesapi": restCountriesStatus,
		"version":          "v1",
		"uptime":           uptime,
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(status)
}
