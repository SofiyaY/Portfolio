package main

import (
	"Assignment1/handlers"
	"fmt"
	"github.com/gorilla/mux"
	"log"
	"net/http"
	"time"
)

func main() {
	// Sets global start time for uptime calculation
	handlers.SetStartTime(time.Now())

	// Creates a new router using gorilla/mux
	r := mux.NewRouter()

	// Registers endpoints
	r.HandleFunc("/countryinfo/v1/info/{two_letter_country_code}", handlers.CountryInfoHandler).Methods("GET")
	r.HandleFunc("/countryinfo/v1/population/{two_letter_country_code}", handlers.PopulationHandler).Methods("GET")
	r.HandleFunc("/countryinfo/v1/status", handlers.StatusHandler).Methods("GET")

	fmt.Println("Server started at http://localhost:8080")
	log.Fatal(http.ListenAndServe(":8080", r))
}
