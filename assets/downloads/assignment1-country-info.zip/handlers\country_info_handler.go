package handlers

import (
	"Assignment1/models"
	"bytes"
	"encoding/json"
	"fmt"
	"github.com/gorilla/mux"
	"io/ioutil"
	"net/http"
	"sort"
	"strconv"
	"strings"
)

// CountryInfoHandler fetches and combines country info from REST Countries API and a list of cities
// from CountriesNow API. It expects a 2-letter country code (converted to uppercase).
func CountryInfoHandler(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	countryCode := strings.ToUpper(vars["two_letter_country_code"])

	// Call REST Countries API.
	restURL := fmt.Sprintf("http://129.241.150.113:8080/v3.1/alpha/%s", countryCode)
	resp, err := http.Get(restURL)
	if err != nil {
		http.Error(w, "Error calling REST Countries API", http.StatusInternalServerError)
		return
	}
	defer resp.Body.Close()

	// Check status code before reading body.
	if resp.StatusCode != http.StatusOK {
		bodyBytes, _ := ioutil.ReadAll(resp.Body)
		http.Error(w, fmt.Sprintf("REST Countries API error: %s", string(bodyBytes)), http.StatusInternalServerError)
		return
	}

	body, _ := ioutil.ReadAll(resp.Body)

	// Unmarshal the response. The API returns an array.
	var restCountries []models.RestCountry
	if err := json.Unmarshal(body, &restCountries); err != nil || len(restCountries) == 0 {
		http.Error(w, "Error parsing REST Countries API response", http.StatusInternalServerError)
		return
	}
	country := restCountries[0]

	// Extract fields.
	countryName := country.Name.Common
	continents := country.Continents
	population := country.Population
	languages := country.Languages
	borders := country.Borders
	flag := ""
	if png, ok := country.Flags["png"]; ok {
		flag = png
	}
	capital := ""
	if len(country.Capital) > 0 {
		capital = country.Capital[0]
	}

	// Call CountriesNow API for cities.
	citiesURL := "http://129.241.150.113:3500/api/v0.1/countries/cities"
	postBody, _ := json.Marshal(map[string]string{"country": countryName})
	citiesResp, err := http.Post(citiesURL, "application/json", bytes.NewBuffer(postBody))
	cities := []string{}
	if err == nil {
		defer citiesResp.Body.Close()
		cBody, err := ioutil.ReadAll(citiesResp.Body)
		if err == nil {
			var citiesData struct {
				Error bool     `json:"error"`
				Msg   string   `json:"msg"`
				Data  []string `json:"data"`
			}
			if err := json.Unmarshal(cBody, &citiesData); err == nil {
				cities = citiesData.Data
			}
		}
	}

	// Sort cities alphabetically and limit if requested.
	sort.Strings(cities)
	// Check for the "limit" query parameter and trim whitespace.
	limitParam := strings.TrimSpace(r.URL.Query().Get("limit"))
	if limitParam != "" {
		if limit, err := strconv.Atoi(limitParam); err == nil && limit < len(cities) {
			cities = cities[:limit]
		}

	}

	response := models.CountryInfoResponse{
		Name:       countryName,
		Continents: continents,
		Population: population,
		Languages:  languages,
		Borders:    borders,
		Flag:       flag,
		Capital:    capital,
		Cities:     cities,
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)
}
