# Country Information Service

This Go-based REST API provides country details and historical population data by interrogating two external, self-hosted APIs.

### External APIs

- **REST Countries API**
  - **Endpoint:** `http://129.241.150.113:8080/v3.1/`
  - **Documentation:** [http://129.241.150.113:8080/](http://129.241.150.113:8080/)

- **CountriesNow API**
  - **Endpoint:** `http://129.241.150.113:3500/api/v0.1/`
  - **Documentation:** [https://documenter.getpostman.com/view/1134062/T1LJjU52](https://documenter.getpostman.com/view/1134062/T1LJjU52)

---

## Endpoints

1. **Country Info**  
   **GET** `/countryinfo/v1/info/{two_letter_country_code}?limit={number}`  
   Returns general country info (name, continents, population, languages, borders, flag, capital) and an alphabetically sorted list of cities.  
   *Example:*
  - `GET http://localhost:8080/countryinfo/v1/info/no`
  - `GET http://localhost:8080/countryinfo/v1/info/no?limit=5`

2. **Population**  
   **GET** `/countryinfo/v1/population/{two_letter_country_code}?limit={startYear-endYear}`  
   Returns historical population data for the country and the mean value. The optional limit filters data between the specified years.  
   *Example:*
  - `GET http://localhost:8080/countryinfo/v1/population/no`
  - `GET http://localhost:8080/countryinfo/v1/population/no?limit=2010-2015`

3. **Diagnostics (Status)**  
   **GET** `/countryinfo/v1/status`  
   Returns a status overview of the external APIs and the service uptime.  
   *Example:*
  - `GET http://localhost:8080/countryinfo/v1/status`

---

## How to Run

1. Navigate to the project directory.
2. Run the service with:
   ```bash
   go run main.go
   ```
3. The server starts at: `http://localhost:8080`

---

## Testing

You can test the endpoints using a REST client, curl, or simply by entering the URL in a web browser. For example:

- **Country Info:**  
  Open: `http://localhost:8080/countryinfo/v1/info/no`

- **Population:**  
  Open: `http://localhost:8080/countryinfo/v1/population/no?limit=2010-2015`

- **Status:**  
  Open: `http://localhost:8080/countryinfo/v1/status`

*Note: This service is intended for internal use. You can access the endpoints directly via your browser for quick testing.*
