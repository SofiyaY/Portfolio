package models

// Population represents information about a city and its population
type Population struct {
	City       string `json:"city"`
	Country    string `json:"country"`
	Population int    `json:"population"`
}

// PopulationYearValue represents population data for a specific year.
type PopulationYearValue struct {
	Year  int `json:"year"`
	Value int `json:"value"`
}

// PopulationResponse is the final output structure for the /population endpoint.
type PopulationResponse struct {
	Mean   int                   `json:"mean"`
	Values []PopulationYearValue `json:"values"`
}
