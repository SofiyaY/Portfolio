package handlers

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"strconv"
	"strings"

	"github.com/gorilla/mux"
)

// PopulationYearValue represents population data for a specific year.
type PopulationYearValue struct {
	Year  int `json:"year"`
	Value int `json:"value"`
}

// PopulationResponse represents the JSON structure for the population endpoint.
type PopulationResponse struct {
	Mean   int                   `json:"mean"`
	Values []PopulationYearValue `json:"values"`
}

// PopulationHandler fetches population data for a country.
// It retrieves the country name from the REST Countries API and then finds the corresponding
// population data from the CountriesNow API. It has an optional "limit" parameter for filtering by year range.
func PopulationHandler(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	// Convert country code to uppercase.
	countryCode := strings.ToUpper(vars["two_letter_country_code"])

	// Update REST Countries API URL
	restURL := fmt.Sprintf("http://129.241.150.113:8080/v3.1/alpha/%s", countryCode)
	resp, err := http.Get(restURL)
	if err != nil {
		http.Error(w, "Error calling REST Countries API", http.StatusInternalServerError)
		return
	}
	defer resp.Body.Close()
	body, _ := ioutil.ReadAll(resp.Body)
	var countries []map[string]interface{}
	json.Unmarshal(body, &countries)
	if len(countries) == 0 {
		http.Error(w, "No country data found", http.StatusInternalServerError)
		return
	}
	nameData := countries[0]["name"].(map[string]interface{})
	countryName := nameData["common"].(string)
	if countryName == "" {
		http.Error(w, "Country name not found", http.StatusInternalServerError)
		return
	}

	// Update CountriesNow API URL for population data.
	popURL := "http://129.241.150.113:3500/api/v0.1/countries/population"
	popResp, err := http.Get(popURL)
	if err != nil {
		http.Error(w, "Error calling CountriesNow API", http.StatusInternalServerError)
		return
	}
	defer popResp.Body.Close()
	popBody, _ := ioutil.ReadAll(popResp.Body)
	var popData map[string]interface{}
	json.Unmarshal(popBody, &popData)
	dataArray := popData["data"].([]interface{})
	var targetCountry map[string]interface{}
	for _, item := range dataArray {
		c := item.(map[string]interface{})
		if strings.EqualFold(c["country"].(string), countryName) {
			targetCountry = c
			break
		}
	}
	if targetCountry == nil {
		http.Error(w, "Population data not found", http.StatusNotFound)
		return
	}

	// Retrieve population counts.
	popCounts := targetCountry["populationCounts"].([]interface{})

	// Process an optional limit parameter ("limit=startYear-endYear").
	limitParam := r.URL.Query().Get("limit")
	startYear, endYear := 0, 0
	if limitParam != "" {
		parts := strings.Split(limitParam, "-")
		if len(parts) == 2 {
			startYear, _ = strconv.Atoi(parts[0])
			endYear, _ = strconv.Atoi(parts[1])
		}
	}

	var values []PopulationYearValue
	sum, count := 0, 0
	for _, v := range popCounts {
		entry := v.(map[string]interface{})
		year := int(entry["year"].(float64))
		if startYear != 0 && endYear != 0 && (year < startYear || year > endYear) {
			continue
		}
		val := int(entry["value"].(float64))
		values = append(values, PopulationYearValue{Year: year, Value: val})
		sum += val
		count++
	}
	mean := 0
	if count > 0 {
		mean = sum / count
	}

	response := PopulationResponse{
		Mean:   mean,
		Values: values,
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)
}
