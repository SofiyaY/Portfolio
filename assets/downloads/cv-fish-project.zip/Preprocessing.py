# -*- coding: utf-8 -*-
"""
Created on Sat Apr 12 18:05:25 2025

@author: sofiy
"""

import numpy as np
import matplotlib.pyplot as plt
import os
import cv2
from skimage import color

# List of images to be preprocessed
image_filenames = ['croppedfish.png', 'fishtank.png']

# Preprocessing functions
def adjust_brightness_contrast(img):
    return cv2.convertScaleAbs(img, alpha=1.5, beta=50)

def to_hsv(img):
    return cv2.cvtColor(img, cv2.COLOR_RGB2HSV)

def to_ycrcb(img):
    return cv2.cvtColor(img, cv2.COLOR_RGB2YCrCb)

def gaussian_blur(img):
    return cv2.GaussianBlur(img, (5, 5), 0)

def median_blur(img):
    return cv2.medianBlur(img, 5)

def flip_horizontal(img):
    return cv2.flip(img, 1)

def flip_vertical(img):
    return cv2.flip(img, 0)

def flip_both(img):
    return cv2.flip(img, -1)

def rotate(img):
    (h, w) = img.shape[:2]
    M = cv2.getRotationMatrix2D((w // 2, h // 2), 30, 1.0)
    return cv2.warpAffine(img, M, (w, h))

def shrink(img):
    return cv2.resize(img, (int(img.shape[1] * 0.7), int(img.shape[0] * 0.7)))

def laplacian_edge(img):
    gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
    return cv2.convertScaleAbs(cv2.Laplacian(gray, cv2.CV_64F))

# List of transformations to apply
transformations = [
    ("Original", lambda x: x),
    ("Bright + contrast", adjust_brightness_contrast),
    ("HSV colorspace", to_hsv),
    ("Flipped h.", flip_horizontal),
    ("Flipped v.", flip_vertical),
    ("Flipped v. + h.", flip_both),
    ("YCrCb colorspace", to_ycrcb),
    ("Gaussian Blur", gaussian_blur),
    ("Median Blur", median_blur),
    ("Rotated", rotate),
    ("Shrunk", shrink),
    ("Laplacian edge", laplacian_edge),
]

# Create output directory if it doesn't exist
output_dir = "preprocessed_images"
os.makedirs(output_dir, exist_ok=True)


#ChatGPT generated to save each preprocessed image in a folder, as well as 
#displaying all the preprocessed images as a plot

# Loop through all images and apply each transformation
for filename in image_filenames:
    image = cv2.imread(filename)
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    base_name = os.path.splitext(os.path.basename(filename))[0]

    # Set up figure for displaying all transformations
    fig, axes = plt.subplots(3, 4, figsize=(12, 8))
    fig.suptitle(f"Preprocessing: {filename}", fontsize=14)

    for ax, (title, func) in zip(axes.flatten(), transformations):
        processed = func(image_rgb)

        # Convert back to BGR format for saving with OpenCV
        if len(processed.shape) == 3 and processed.shape[2] == 3:
            processed_bgr = cv2.cvtColor(processed, cv2.COLOR_RGB2BGR)
        else:
            processed_bgr = processed  # Grayscale or single-channel

        # Save individual image
        out_path = os.path.join(output_dir, f"{base_name}_{title.replace(' ', '_')}.png")
        cv2.imwrite(out_path, processed_bgr)

        # Show transformation in subplot
        if len(processed.shape) == 2:
            ax.imshow(processed, cmap='gray')
        else:
            ax.imshow(processed)
        ax.set_title(title)
        ax.axis('off')

    # Hide empty subplots if needed
    for ax in axes.flatten()[len(transformations):]:
        ax.axis('off')

    plt.tight_layout()
    plt.subplots_adjust(top=0.88)
    plt.show()