# -*- coding: utf-8 -*-
"""
Created on Mon Apr 14 19:47:55 2025

@author: sofiy
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import os
import cv2  # Importing OpenCV 

# Function for gradient-based edge detection
def edge_detection(image):
    # Compute horizontal and vertical gradients (f_x and f_y)
    f_x = np.gradient(image, axis=1)
    f_x[np.isnan(f_x)] = 0
    f_y = np.gradient(image, axis=0)
    f_y[np.isnan(f_y)] = 0

    # Compute the gradient magnitude using the Pythagorean theorem
    fgradabs = np.sqrt(f_x**2 + f_y**2)
    fgradabs[np.isnan(fgradabs)] = 0

    # Normalize the result for visualization
    min_value = np.min(fgradabs)
    max_value = np.max(fgradabs)
    fgradabs_scaled = (fgradabs - min_value) / (max_value - min_value)
    
    # Display the normalized gradient magnitude
    plt.title("Gradient Magnitude (Scaled)")
    plt.imshow(fgradabs_scaled, cmap='gray')
    plt.axis('off')
    plt.show()

    # Threshold function for binary edge detection
    def kutt(x):
        c = 0.13  # Threshold value
        return 0.0 if x <= c else 1.0

    kutt = np.frompyfunc(kutt, 1, 1)
    edges = np.vectorize(kutt)(fgradabs_scaled)

    # Display binary edge result
    plt.imshow(edges, cmap='gray')
    plt.title("Binary Edges (Thresholded)")
    plt.axis('off')
    plt.show()

# Function for Euler integration with anisotropic diffusion
def diffusion(image, lmbda=0.01, dt=0.1, num_iterations=300): 
    image2 = np.copy(image)

    # Weighting function based on gradient magnitude
    def g_x(x, lmbda):
        return 1 / (np.sqrt(1 + (x)**2 / (lmbda**2)))
    
    # Perform iterative diffusion
    for i in range(num_iterations):
        f_x = np.gradient(image2, axis=1)
        f_y = np.gradient(image2, axis=0)
        f_xx = np.gradient(f_x, axis=1) * g_x(f_x, lmbda)
        f_yy = np.gradient(f_y, axis=0) * g_x(f_y, lmbda)
        image2 += dt * (f_xx + f_yy)
    
    return image2

# Combined function: diffusion + edge detection
def edge_detection_with_diffusion(image, lmbda, dt, num_iterations, c):
    # Apply diffusion as preprocessing
    image2 = diffusion(image, lmbda, dt, num_iterations)

    # Compute gradient magnitude on the smoothed image
    f_x = np.gradient(image2, axis=1)
    f_y = np.gradient(image2, axis=0)
    fgradabs = np.sqrt(f_x**2 + f_y**2)
    fgradabs[np.isnan(fgradabs)] = 0

    # Normalize
    min_value = np.min(fgradabs)
    max_value = np.max(fgradabs)
    fgradabs_scaled = (fgradabs - min_value) / (max_value - min_value)

    # Apply threshold
    def kutt(x):
        return 0.0 if x <= c else 1.0

    kutt = np.frompyfunc(kutt, 1, 1)
    edges = np.vectorize(kutt)(fgradabs_scaled)

    # Display result
    plt.imshow(edges, cmap='gray')
    plt.title(f"Edges After Diffusion | λ = {lmbda}, ∆t = {dt}")
    plt.axis('off')
    plt.show()

# Canny edge detection using OpenCV
def canny_edge_detection(image):
    # Convert image to grayscale
    gray_image = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)

    # Convert to 8-bit format (0–255 scale)
    gray_image_8bit = np.uint8(gray_image * 255)

    # Apply Canny edge detection with two threshold values
    edges = cv2.Canny(gray_image_8bit, 100, 200)
    plt.imshow(edges)
    plt.title("Canny Edge Detection")
    plt.axis('off')
    plt.show()

# Contour detection based on Canny edges
def basic_contour_detection(image_path):
    # Load the input image
    image = cv2.imread(image_path)

    # Convert to grayscale and apply Gaussian blur
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (5, 5), 0)

    # Apply Canny detection
    edges = cv2.Canny(blur, 30, 150)

    # Detect contours
    contours, _ = cv2.findContours(edges.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # Draw contours on a blank canvas
    contour_image = np.zeros_like(image)
    cv2.drawContours(contour_image, contours, -1, (0, 255, 0), 2)

    # Display result
    plt.imshow(cv2.cvtColor(contour_image, cv2.COLOR_BGR2RGB))
    plt.title("Contour Detection (Canny)")
    plt.axis('off')
    plt.show()


# Define image file to use
image_filename = 'fishtank.png'
image_path = os.path.join(image_filename)

# Read and process image
image = mpimg.imread(image_path)

# Apply edge detection
edge_detection(image)

# Apply edge detection after diffusion
lmbda = 0.01
dt = 0.001
num_iterations = 100
c = 0.11
edge_detection_with_diffusion(image, lmbda, dt, num_iterations, c)

# Apply Canny edge detection
canny_edge_detection(image)

# Apply contour detection
basic_contour_detection(image_path)


